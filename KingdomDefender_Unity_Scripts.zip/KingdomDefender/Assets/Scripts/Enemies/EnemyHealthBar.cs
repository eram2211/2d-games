using UnityEngine;
using UnityEngine.UI;

namespace KingdomDefender.Enemies
{
    /// <summary>
    /// Simple world-space health bar (put on a Canvas set to "World Space",
    /// parented above the enemy's head). Fill image scales with health percent.
    /// </summary>
    public class EnemyHealthBar : MonoBehaviour
    {
        [SerializeField] private Image fillImage;
        [SerializeField] private bool billboardToCamera = true;

        private Camera _cam;

        private void Awake()
        {
            _cam = Camera.main;
        }

        public void SetHealth(float normalizedHealth)
        {
            if (fillImage != null)
                fillImage.fillAmount = Mathf.Clamp01(normalizedHealth);
        }

        private void LateUpdate()
        {
            if (billboardToCamera && _cam != null)
            {
                transform.forward = _cam.transform.forward;
            }
        }
    }
}
