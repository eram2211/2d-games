using UnityEngine;
using KingdomDefender.Data;

namespace KingdomDefender.Enemies
{
    /// <summary>
    /// Moves this enemy along a PathWaypoints route at its own speed.
    /// Flying enemies visually hover (extra Y offset + no rotation snapping issues
    /// with ground obstacles); ground/tank enemies stick to the path height.
    /// When the last waypoint is reached, notifies the Enemy to damage the castle.
    /// </summary>
    [RequireComponent(typeof(Enemy))]
    public class PathFollower : MonoBehaviour
    {
        [SerializeField] private float waypointReachedDistance = 0.15f;
        [SerializeField] private float flyingHeightOffset = 1.5f;

        private PathWaypoints _path;
        private int _currentWaypointIndex;
        private Enemy _enemy;
        private float _currentSpeed;

        public float DistanceTraveled { get; private set; } // used for "closest to castle" targeting

        public void Initialize(PathWaypoints path, Enemy enemy)
        {
            _path = path;
            _enemy = enemy;
            _currentWaypointIndex = 0;
            DistanceTraveled = 0f;
            _currentSpeed = enemy.Data.moveSpeed;

            Vector3 start = _path.GetPoint(0);
            if (enemy.Data.movementType == EnemyMovementType.Flying)
                start.y += flyingHeightOffset;
            transform.position = start;
        }

        public void SetSpeedMultiplier(float multiplier)
        {
            _currentSpeed = _enemy.Data.moveSpeed * multiplier;
        }

        public void ResetSpeed()
        {
            _currentSpeed = _enemy.Data.moveSpeed;
        }

        private void Update()
        {
            if (_path == null || _currentWaypointIndex >= _path.Count) return;

            Vector3 target = _path.GetPoint(_currentWaypointIndex);
            if (_enemy.Data.movementType == EnemyMovementType.Flying)
                target.y += flyingHeightOffset;

            Vector3 toTarget = target - transform.position;
            float step = _currentSpeed * Time.deltaTime;

            if (toTarget.magnitude <= waypointReachedDistance)
            {
                _currentWaypointIndex++;
                if (_currentWaypointIndex >= _path.Count)
                {
                    _enemy.ReachCastle();
                    return;
                }
            }
            else
            {
                Vector3 direction = toTarget.normalized;
                transform.position += direction * step;
                DistanceTraveled += step;

                // Face movement direction (simple 2D sprite flip / rotation)
                if (direction.x != 0f)
                {
                    Vector3 scale = transform.localScale;
                    scale.x = Mathf.Abs(scale.x) * (direction.x < 0 ? -1f : 1f);
                    transform.localScale = scale;
                }
            }
        }
    }
}
