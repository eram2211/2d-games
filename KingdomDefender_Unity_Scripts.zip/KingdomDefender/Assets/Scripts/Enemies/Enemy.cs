using System;
using UnityEngine;
using KingdomDefender.Core;
using KingdomDefender.Data;
using KingdomDefender.Castle;

namespace KingdomDefender.Enemies
{
    /// <summary>
    /// Runtime behaviour for a single enemy instance. Works for ALL 5 enemy types
    /// (Goblin, Orc, Wraith, Troll, boss) because everything type-specific lives
    /// in the EnemyData asset, not in code. Implements IPoolable so it is
    /// recycled instead of destroyed when it dies or reaches the castle.
    /// </summary>
    [RequireComponent(typeof(PathFollower))]
    public class Enemy : MonoBehaviour, IPoolable
    {
        [SerializeField] private Animator animator; // optional - walk/hit/die triggers
        [SerializeField] private EnemyHealthBar healthBar;
        [SerializeField] private GameObject deathParticlesPrefab;
        [SerializeField] private GameObject hitParticlesPrefab;

        public EnemyData Data { get; private set; }
        public float CurrentHealth { get; private set; }
        public bool IsDead { get; private set; }

        private PathFollower _pathFollower;
        private ObjectPool _pool;
        private GameObject _sourcePrefab;

        public event Action<Enemy> OnDeath;
        public event Action<Enemy> OnReachedCastle;

        private void Awake()
        {
            _pathFollower = GetComponent<PathFollower>();
        }

        /// <summary>Called by the WaveManager right after this instance is fetched from the pool.</summary>
        public void Setup(EnemyData data, PathWaypoints path, GameObject sourcePrefab)
        {
            Data = data;
            _sourcePrefab = sourcePrefab;
            CurrentHealth = data.maxHealth;
            IsDead = false;

            _pathFollower.Initialize(path, this);
            healthBar?.SetHealth(1f);
            healthBar?.gameObject.SetActive(false); // only show once damaged

            animator?.SetBool("IsFlying", data.movementType == EnemyMovementType.Flying);
            animator?.Play("Walk");
        }

        public bool IsFlying => Data.movementType == EnemyMovementType.Flying;
        public bool IsTank => Data.movementType == EnemyMovementType.Tank;

        public void TakeDamage(float amount)
        {
            if (IsDead) return;

            float mitigated = amount * (1f - Data.damageResistance);
            CurrentHealth -= mitigated;

            if (hitParticlesPrefab != null && ObjectPoolManager.Instance != null)
            {
                ObjectPoolManager.Instance.Spawn(hitParticlesPrefab, transform.position, Quaternion.identity);
            }

            if (healthBar != null)
            {
                healthBar.gameObject.SetActive(true);
                healthBar.SetHealth(Mathf.Clamp01(CurrentHealth / Data.maxHealth));
            }

            animator?.SetTrigger("Hit");

            if (CurrentHealth <= 0f)
            {
                Die();
            }
        }

        /// <summary>Slows this enemy's movement (e.g. Mage tower frost effect).</summary>
        public void ApplySlow(float multiplier, float duration)
        {
            if (IsDead) return;
            CancelInvoke(nameof(ClearSlow));
            _pathFollower.SetSpeedMultiplier(multiplier);
            Invoke(nameof(ClearSlow), duration);
        }

        private void ClearSlow()
        {
            if (!IsDead) _pathFollower.ResetSpeed();
        }

        private void Die()
        {
            IsDead = true;
            animator?.SetTrigger("Die");

            if (deathParticlesPrefab != null && ObjectPoolManager.Instance != null)
            {
                ObjectPoolManager.Instance.Spawn(deathParticlesPrefab, transform.position, Quaternion.identity);
            }

            GameManager.Instance?.AddCoins(Data.coinReward);
            GameManager.Instance?.AddScore(Data.isBoss ? 500 : 10);

            OnDeath?.Invoke(this);
            ReturnToPool();
        }

        /// <summary>Called by PathFollower when this enemy reaches the final waypoint.</summary>
        public void ReachCastle()
        {
            if (IsDead) return;
            IsDead = true;

            CastleHealth castle = CastleHealth.Instance;
            castle?.TakeDamage(Data.damageToCastle);

            OnReachedCastle?.Invoke(this);
            ReturnToPool();
        }

        // ----- IPoolable -----
        public void SetPool(ObjectPool pool) => _pool = pool;

        public void OnSpawn()
        {
            IsDead = false;
        }

        public void ReturnToPool()
        {
            CancelInvoke();
            if (_pool != null)
            {
                _pool.Return(gameObject);
            }
            else if (ObjectPoolManager.Instance != null && _sourcePrefab != null)
            {
                ObjectPoolManager.Instance.Return(_sourcePrefab, gameObject);
            }
            else
            {
                Destroy(gameObject); // fallback safety net
            }
        }
    }
}
