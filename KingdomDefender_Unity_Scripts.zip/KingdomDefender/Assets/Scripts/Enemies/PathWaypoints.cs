using UnityEngine;

namespace KingdomDefender.Enemies
{
    /// <summary>
    /// Defines the route enemies walk from spawn to the castle.
    /// Drop empty GameObjects as children (in order) and assign them here,
    /// or just position them in the array via the inspector.
    /// Draws gizmo lines in the editor so level designers can see the path.
    /// </summary>
    public class PathWaypoints : MonoBehaviour
    {
        [SerializeField] private Transform[] waypoints;

        public int Count => waypoints != null ? waypoints.Length : 0;

        public Vector3 GetPoint(int index)
        {
            index = Mathf.Clamp(index, 0, Count - 1);
            return waypoints[index].position;
        }

        private void OnDrawGizmos()
        {
            if (waypoints == null || waypoints.Length < 2) return;

            Gizmos.color = Color.yellow;
            for (int i = 0; i < waypoints.Length - 1; i++)
            {
                if (waypoints[i] == null || waypoints[i + 1] == null) continue;
                Gizmos.DrawLine(waypoints[i].position, waypoints[i + 1].position);
                Gizmos.DrawSphere(waypoints[i].position, 0.15f);
            }
            Gizmos.DrawSphere(waypoints[waypoints.Length - 1].position, 0.15f);
        }
    }
}
