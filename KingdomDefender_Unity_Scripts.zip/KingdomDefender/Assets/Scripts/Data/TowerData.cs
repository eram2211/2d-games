using UnityEngine;

namespace KingdomDefender.Data
{
    public enum TargetPriority { First, Closest, Strongest, Weakest }

    /// <summary>
    /// One upgrade tier for a tower. TowerData holds an array of these; index 0
    /// is the tower's base (level 1) stats, and each subsequent entry is what the
    /// tower becomes when upgraded again.
    /// </summary>
    [System.Serializable]
    public class TowerUpgradeLevel
    {
        public int upgradeCost = 50;
        public float damage = 10f;
        public float range = 4f;
        public float fireRate = 1f; // shots per second
        public bool canHitFlying = true;
        public GameObject visualPrefab; // optional: swap tower model on upgrade
    }

    /// <summary>
    /// Data-driven tower definition. To add a 5th tower, create a new TowerData
    /// asset (Assets > Create > KingdomDefender > Tower Data), fill in upgrade
    /// levels, and add it to the Shop's tower list. No new C# class required
    /// unless the tower needs a wholly unique special ability.
    ///
    /// The 4 required tower types map to assets like:
    ///   Archer Tower  - fast, low damage, hits flying
    ///   Cannon Tower  - slow, high splash damage, ground only
    ///   Mage Tower    - medium rate, magic damage + slow effect, hits flying
    ///   Ballista Tower- long range, high single-target damage, hits flying
    /// </summary>
    [CreateAssetMenu(fileName = "NewTower", menuName = "KingdomDefender/Tower Data")]
    public class TowerData : ScriptableObject
    {
        [Header("Identity")]
        public string towerName = "Archer Tower";
        public Sprite icon;
        public GameObject towerPrefab;
        public GameObject projectilePrefab;

        [Header("Economy")]
        public int buildCost = 50;

        [Header("Behaviour")]
        public TargetPriority defaultPriority = TargetPriority.First;
        public bool hasSplashDamage = false;
        public float splashRadius = 0f;
        public bool appliesSlow = false;
        [Range(0f, 1f)] public float slowMultiplier = 0.5f;
        public float slowDuration = 2f;

        [Header("Upgrade path (index 0 = base level)")]
        public TowerUpgradeLevel[] upgradeLevels;

        public int MaxLevel => upgradeLevels != null ? upgradeLevels.Length : 1;

        public TowerUpgradeLevel GetLevel(int levelIndex)
        {
            if (upgradeLevels == null || upgradeLevels.Length == 0) return null;
            levelIndex = Mathf.Clamp(levelIndex, 0, upgradeLevels.Length - 1);
            return upgradeLevels[levelIndex];
        }
    }
}
