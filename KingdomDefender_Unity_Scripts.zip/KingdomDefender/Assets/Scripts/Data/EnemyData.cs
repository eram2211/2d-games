using UnityEngine;

namespace KingdomDefender.Data
{
    public enum EnemyMovementType { Ground, Flying, Tank }

    /// <summary>
    /// Data-driven enemy definition. To add a 6th enemy type, an artist/designer
    /// creates a new EnemyData asset (Assets > Create > KingdomDefender > Enemy Data)
    /// and drops it into the WaveData list - zero new code required.
    ///
    /// The 5 required enemy types map to assets like:
    ///   Goblin   (Ground, fast, low HP)
    ///   Orc      (Ground, medium)
    ///   Wraith   (Flying, medium HP, ignores ground-only towers)
    ///   Troll    (Tank, slow, very high HP)
    ///   Dark Knight (Boss - used on every 5th wave)
    /// </summary>
    [CreateAssetMenu(fileName = "NewEnemy", menuName = "KingdomDefender/Enemy Data")]
    public class EnemyData : ScriptableObject
    {
        [Header("Identity")]
        public string enemyName = "Goblin";
        public GameObject prefab;
        public Sprite icon;

        [Header("Stats")]
        public float maxHealth = 50f;
        public float moveSpeed = 2.5f;
        public int coinReward = 5;
        public int damageToCastle = 1;

        [Header("Type flags")]
        public EnemyMovementType movementType = EnemyMovementType.Ground;
        [Tooltip("Tank enemies take reduced damage from single-target towers but are slow and high HP.")]
        public float damageResistance = 0f; // 0 - 1, percentage damage reduction

        [Header("Boss")]
        public bool isBoss = false;
    }
}
