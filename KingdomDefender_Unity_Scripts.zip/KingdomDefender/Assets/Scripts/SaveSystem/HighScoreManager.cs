using UnityEngine;

namespace KingdomDefender.SaveSystem
{
    /// <summary>
    /// Persists the player's best score between sessions using PlayerPrefs.
    /// Swap the PlayerPrefs calls for JSON/file storage later without touching
    /// any other script, since everything talks to this manager only.
    /// </summary>
    public class HighScoreManager : MonoBehaviour
    {
        private const string HighScoreKey = "KingdomDefender_HighScore";

        public static HighScoreManager Instance { get; private set; }

        public int HighScore { get; private set; }

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            HighScore = PlayerPrefs.GetInt(HighScoreKey, 0);
        }

        /// <summary>Saves the score only if it beats the current high score. Returns true if a new record was set.</summary>
        public bool TrySaveHighScore(int score)
        {
            if (score <= HighScore) return false;

            HighScore = score;
            PlayerPrefs.SetInt(HighScoreKey, HighScore);
            PlayerPrefs.Save();
            return true;
        }

        public void ResetHighScore()
        {
            HighScore = 0;
            PlayerPrefs.SetInt(HighScoreKey, 0);
            PlayerPrefs.Save();
        }
    }
}
