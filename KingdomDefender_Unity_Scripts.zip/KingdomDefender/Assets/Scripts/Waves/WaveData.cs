using UnityEngine;
using KingdomDefender.Data;

namespace KingdomDefender.Waves
{
    [System.Serializable]
    public class WaveEntry
    {
        public EnemyData enemyType;
        public int count = 5;
        public float spawnInterval = 0.8f;
    }

    /// <summary>
    /// Optional hand-authored wave (Assets > Create > KingdomDefender > Wave Data).
    /// If you'd rather waves scale procedurally, WaveManager can generate them
    /// automatically instead - see WaveManager.GenerateProceduralWave().
    /// </summary>
    [CreateAssetMenu(fileName = "NewWave", menuName = "KingdomDefender/Wave Data")]
    public class WaveData : ScriptableObject
    {
        public WaveEntry[] entries;
        public bool isBossWave;
        public EnemyData bossOverride; // used when isBossWave is true
    }
}
