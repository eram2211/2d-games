using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using KingdomDefender.Core;
using KingdomDefender.Data;
using KingdomDefender.Enemies;

namespace KingdomDefender.Waves
{
    /// <summary>
    /// Drives the whole wave/round loop:
    ///   - Counts down a "prep" timer between waves so the player can build/upgrade.
    ///   - Spawns enemies through ObjectPoolManager (no per-wave GC allocation).
    ///   - Every 5th wave (5, 10, 15, ...) is a Boss Wave with one tough boss enemy
    ///     plus a smaller escort group.
    ///   - Fires OnVictory once totalWaves is cleared and no enemies remain alive.
    /// Efficient spawning: uses a single coroutine + queue rather than Instantiating
    /// everything up front, and reuses instances via ObjectPoolManager.
    /// </summary>
    public class WaveManager : MonoBehaviour
    {
        [Header("References")]
        [SerializeField] private PathWaypoints path;
        [SerializeField] private Transform spawnPoint;

        [Header("Hand-authored waves (optional, checked first)")]
        [SerializeField] private List<WaveData> authoredWaves = new List<WaveData>();

        [Header("Procedural fallback pool (used past authored waves or if list is empty)")]
        [SerializeField] private List<EnemyData> regularEnemyPool = new List<EnemyData>();
        [SerializeField] private EnemyData bossEnemyData;

        [Header("Pacing")]
        [SerializeField] private int totalWaves = 20;
        [SerializeField] private int bossWaveInterval = 5;
        [SerializeField] private float timeBetweenWaves = 12f;
        [SerializeField] private float baseSpawnInterval = 0.7f;

        public int CurrentWave { get; private set; } = 0;
        public int TotalWaves => totalWaves;
        public float TimeUntilNextWave { get; private set; }
        public bool IsBossWaveIncoming => (CurrentWave + 1) % bossWaveInterval == 0;

        public event Action<int> OnWaveStarted;
        public event Action<int, bool> OnWaveCompleted; // wave number, wasBossWave
        public event Action OnAllWavesCleared;

        private readonly List<Enemy> _aliveEnemies = new List<Enemy>();
        private int _enemiesRemainingToSpawn;
        private bool _victoryDeclared;

        public IReadOnlyList<Enemy> AliveEnemies => _aliveEnemies;

        private void Start()
        {
            StartCoroutine(RunWaves());
        }

        private IEnumerator RunWaves()
        {
            while (CurrentWave < totalWaves)
            {
                // Prep countdown between waves
                TimeUntilNextWave = timeBetweenWaves;
                while (TimeUntilNextWave > 0f)
                {
                    if (GameManager.Instance == null || GameManager.Instance.State == GameState.Playing)
                        TimeUntilNextWave -= Time.deltaTime;
                    yield return null;
                }

                CurrentWave++;
                bool isBossWave = CurrentWave % bossWaveInterval == 0;
                OnWaveStarted?.Invoke(CurrentWave);

                yield return StartCoroutine(SpawnWave(CurrentWave, isBossWave));

                // Wait until every enemy from this wave is dead or has reached the castle
                yield return new WaitUntil(() => _aliveEnemies.Count == 0);

                OnWaveCompleted?.Invoke(CurrentWave, isBossWave);
            }

            if (!_victoryDeclared)
            {
                _victoryDeclared = true;
                OnAllWavesCleared?.Invoke();
                GameManager.Instance?.SetState(GameState.Victory);
            }
        }

        private IEnumerator SpawnWave(int waveNumber, bool isBossWave)
        {
            List<(EnemyData data, float interval)> spawnList = BuildSpawnList(waveNumber, isBossWave);
            _enemiesRemainingToSpawn = spawnList.Count;

            foreach (var (data, interval) in spawnList)
            {
                SpawnEnemy(data);
                _enemiesRemainingToSpawn--;

                // Pause spawning (but not the whole wave loop) if the game is paused
                yield return new WaitUntil(() => GameManager.Instance == null || GameManager.Instance.State != GameState.Paused);
                yield return new WaitForSeconds(interval);
            }
        }

        private List<(EnemyData, float)> BuildSpawnList(int waveNumber, bool isBossWave)
        {
            var list = new List<(EnemyData, float)>();

            // Prefer a hand-authored wave if the designer made one for this slot
            int authoredIndex = waveNumber - 1;
            if (authoredIndex >= 0 && authoredIndex < authoredWaves.Count && authoredWaves[authoredIndex] != null)
            {
                WaveData wd = authoredWaves[authoredIndex];
                foreach (var entry in wd.entries)
                {
                    for (int i = 0; i < entry.count; i++)
                        list.Add((entry.enemyType, entry.spawnInterval));
                }
                return list;
            }

            // Procedural generation otherwise
            if (isBossWave && bossEnemyData != null)
            {
                list.Add((bossEnemyData, 1.5f));

                // A smaller escort so the boss wave isn't ONLY a single enemy
                int escortCount = 3 + waveNumber / bossWaveInterval;
                for (int i = 0; i < escortCount; i++)
                {
                    EnemyData escort = regularEnemyPool[UnityEngine.Random.Range(0, regularEnemyPool.Count)];
                    list.Add((escort, baseSpawnInterval));
                }
            }
            else
            {
                int enemyCount = 5 + waveNumber * 2; // scales with wave number
                float interval = Mathf.Max(0.25f, baseSpawnInterval - waveNumber * 0.015f); // gets a little faster
                for (int i = 0; i < enemyCount; i++)
                {
                    EnemyData chosen = regularEnemyPool[UnityEngine.Random.Range(0, regularEnemyPool.Count)];
                    list.Add((chosen, interval));
                }
            }

            return list;
        }

        private void SpawnEnemy(EnemyData data)
        {
            if (data == null || data.prefab == null || ObjectPoolManager.Instance == null) return;

            GameObject instance = ObjectPoolManager.Instance.Spawn(data.prefab, spawnPoint.position, Quaternion.identity);
            Enemy enemy = instance.GetComponent<Enemy>();
            enemy.Setup(data, path, data.prefab);

            _aliveEnemies.Add(enemy);
            enemy.OnDeath += HandleEnemyRemoved;
            enemy.OnReachedCastle += HandleEnemyRemoved;
        }

        private void HandleEnemyRemoved(Enemy enemy)
        {
            enemy.OnDeath -= HandleEnemyRemoved;
            enemy.OnReachedCastle -= HandleEnemyRemoved;
            _aliveEnemies.Remove(enemy);
        }
    }
}
