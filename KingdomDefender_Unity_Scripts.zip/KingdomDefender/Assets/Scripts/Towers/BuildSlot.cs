using UnityEngine;

namespace KingdomDefender.Towers
{
    /// <summary>
    /// Marker component for a spot on the map where a tower may be built.
    /// Place these off the enemy path. Requires a Collider2D (set as Trigger)
    /// on the buildSlotLayer for TowerPlacement's OverlapPoint check.
    /// </summary>
    public class BuildSlot : MonoBehaviour
    {
        public bool IsOccupied { get; private set; }
        public Tower OccupyingTower { get; private set; }

        [SerializeField] private SpriteRenderer highlightRenderer; // optional visual "empty slot" ring

        public void MarkOccupied(Tower tower)
        {
            IsOccupied = true;
            OccupyingTower = tower;
            if (highlightRenderer != null) highlightRenderer.enabled = false;
        }

        /// <summary>Called when the player sells the tower on this slot.</summary>
        public void Clear()
        {
            IsOccupied = false;
            OccupyingTower = null;
            if (highlightRenderer != null) highlightRenderer.enabled = true;
        }
    }
}
