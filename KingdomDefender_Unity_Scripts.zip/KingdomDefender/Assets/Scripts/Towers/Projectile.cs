using UnityEngine;
using KingdomDefender.Core;
using KingdomDefender.Enemies;

namespace KingdomDefender.Towers
{
    /// <summary>
    /// A single fired shot. Homes toward its target enemy, deals damage on hit
    /// (with optional splash radius and slow effect), and returns to its pool.
    /// Works for arrows, cannonballs, magic bolts, and ballista spears alike -
    /// the tower configures damage/splash/slow at fire time.
    /// </summary>
    public class Projectile : MonoBehaviour, IPoolable
    {
        [SerializeField] private float speed = 12f;
        [SerializeField] private GameObject impactParticlesPrefab;

        private Enemy _target;
        private float _damage;
        private bool _hasSplash;
        private float _splashRadius;
        private bool _appliesSlow;
        private float _slowMultiplier;
        private float _slowDuration;

        private ObjectPool _pool;
        private GameObject _sourcePrefab;

        public void Fire(Enemy target, float damage, bool hasSplash, float splashRadius,
                          bool appliesSlow, float slowMultiplier, float slowDuration, GameObject sourcePrefab)
        {
            _target = target;
            _damage = damage;
            _hasSplash = hasSplash;
            _splashRadius = splashRadius;
            _appliesSlow = appliesSlow;
            _slowMultiplier = slowMultiplier;
            _slowDuration = slowDuration;
            _sourcePrefab = sourcePrefab;
        }

        private void Update()
        {
            if (_target == null || _target.IsDead)
            {
                ReturnToPool();
                return;
            }

            Vector3 toTarget = _target.transform.position - transform.position;
            float step = speed * Time.deltaTime;

            if (toTarget.magnitude <= step)
            {
                HitTarget();
                return;
            }

            transform.position += toTarget.normalized * step;
            transform.right = toTarget.normalized; // point sprite toward target
        }

        private void HitTarget()
        {
            if (impactParticlesPrefab != null && ObjectPoolManager.Instance != null)
            {
                ObjectPoolManager.Instance.Spawn(impactParticlesPrefab, transform.position, Quaternion.identity);
            }

            if (_hasSplash)
            {
                Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, _splashRadius);
                foreach (var hit in hits)
                {
                    Enemy enemy = hit.GetComponent<Enemy>();
                    if (enemy != null && !enemy.IsDead)
                    {
                        ApplyDamageAndEffects(enemy);
                    }
                }
            }
            else if (_target != null && !_target.IsDead)
            {
                ApplyDamageAndEffects(_target);
            }

            ReturnToPool();
        }

        private void ApplyDamageAndEffects(Enemy enemy)
        {
            enemy.TakeDamage(_damage);
            if (_appliesSlow && !enemy.IsDead)
            {
                enemy.ApplySlow(_slowMultiplier, _slowDuration);
            }
        }

        public void SetPool(ObjectPool pool) => _pool = pool;
        public void OnSpawn() { _target = null; }

        public void ReturnToPool()
        {
            if (_pool != null) _pool.Return(gameObject);
            else if (ObjectPoolManager.Instance != null && _sourcePrefab != null)
                ObjectPoolManager.Instance.Return(_sourcePrefab, gameObject);
            else
                Destroy(gameObject);
        }
    }
}
