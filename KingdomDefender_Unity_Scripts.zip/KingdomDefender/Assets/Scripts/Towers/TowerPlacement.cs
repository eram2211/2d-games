using System;
using UnityEngine;
using KingdomDefender.Core;
using KingdomDefender.Data;
using KingdomDefender.Waves;

namespace KingdomDefender.Towers
{
    /// <summary>
    /// Bridges the Shop UI and the game world:
    ///   1. Player taps a tower in the shop -> BeginPlacement(towerData) is called.
    ///   2. A ghost preview follows the mouse/finger.
    ///   3. Player taps a valid BuildSlot -> tower is instantiated there, coins spent.
    ///   4. Tapping an already-placed tower selects it for the Upgrade UI instead.
    /// Only requires BuildSlot markers in the scene (empty GameObjects with a collider)
    /// so towers can only be placed on the designer-approved spots, not on the path.
    /// </summary>
    public class TowerPlacement : MonoBehaviour
    {
        [SerializeField] private WaveManager waveManager;
        [SerializeField] private LayerMask buildSlotLayer;
        [SerializeField] private LayerMask placedTowerLayer;
        [SerializeField] private GameObject placementGhostPrefab;
        [SerializeField] private Camera mainCamera;

        public event Action<Tower> OnTowerSelected;
        public event Action OnSelectionCleared;

        private TowerData _pendingTower;
        private GameObject _ghostInstance;
        public Tower SelectedTower { get; private set; }

        private void Awake()
        {
            if (mainCamera == null) mainCamera = Camera.main;
        }

        public void BeginPlacement(TowerData towerData)
        {
            CancelPlacement();
            _pendingTower = towerData;

            if (placementGhostPrefab != null)
            {
                _ghostInstance = Instantiate(placementGhostPrefab);
                SpriteRenderer sr = _ghostInstance.GetComponentInChildren<SpriteRenderer>();
                if (sr != null && towerData.icon != null) sr.sprite = towerData.icon;
            }
        }

        public void CancelPlacement()
        {
            _pendingTower = null;
            if (_ghostInstance != null) Destroy(_ghostInstance);
        }

        private void Update()
        {
            if (GameManager.Instance != null && GameManager.Instance.State != GameState.Playing) return;

            if (_pendingTower != null)
            {
                HandlePlacementMode();
            }
            else if (Input.GetMouseButtonDown(0))
            {
                HandleSelectionClick();
            }

            if (Input.GetKeyDown(KeyCode.Escape))
            {
                CancelPlacement();
                DeselectTower();
            }
        }

        private void HandlePlacementMode()
        {
            Vector3 worldPos = GetWorldPointerPosition();
            if (_ghostInstance != null) _ghostInstance.transform.position = worldPos;

            if (Input.GetMouseButtonDown(0))
            {
                Collider2D slotHit = Physics2D.OverlapPoint(worldPos, buildSlotLayer);
                if (slotHit != null && slotHit.GetComponent<BuildSlot>() is BuildSlot slot && !slot.IsOccupied)
                {
                    TryBuildAt(slot);
                }
            }
        }

        private void TryBuildAt(BuildSlot slot)
        {
            if (GameManager.Instance == null || !GameManager.Instance.SpendCoins(_pendingTower.buildCost))
            {
                return; // not enough coins - keep ghost active, let player try another slot or cancel
            }

            GameObject towerObj = Instantiate(_pendingTower.towerPrefab, slot.transform.position, Quaternion.identity);
            Tower tower = towerObj.GetComponent<Tower>();
            tower.Initialize(_pendingTower, waveManager, slot);
            slot.MarkOccupied(tower);

            CancelPlacement();
        }

        /// <summary>Called from the Upgrade UI's "Sell" button for the currently selected tower.</summary>
        public void SellSelectedTower()
        {
            if (SelectedTower == null) return;
            SelectedTower.Sell();
            DeselectTower();
        }

        private void HandleSelectionClick()
        {
            Vector3 worldPos = GetWorldPointerPosition();
            Collider2D towerHit = Physics2D.OverlapPoint(worldPos, placedTowerLayer);

            if (towerHit != null && towerHit.GetComponentInParent<Tower>() is Tower tower)
            {
                SelectedTower = tower;
                OnTowerSelected?.Invoke(tower);
            }
            else
            {
                DeselectTower();
            }
        }

        public void DeselectTower()
        {
            SelectedTower = null;
            OnSelectionCleared?.Invoke();
        }

        private Vector3 GetWorldPointerPosition()
        {
            Vector3 screenPos = Input.mousePosition;
            screenPos.z = -mainCamera.transform.position.z;
            Vector3 world = mainCamera.ScreenToWorldPoint(screenPos);
            world.z = 0f;
            return world;
        }
    }
}
