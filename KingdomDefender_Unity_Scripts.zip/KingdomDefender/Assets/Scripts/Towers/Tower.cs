using System.Collections.Generic;
using UnityEngine;
using KingdomDefender.Core;
using KingdomDefender.Data;
using KingdomDefender.Enemies;
using KingdomDefender.Waves;

namespace KingdomDefender.Towers
{
    /// <summary>
    /// Runtime behaviour for a placed tower. Handles targeting priority,
    /// firing rate, and upgrading through TowerData's upgrade levels.
    /// Because all stats (damage, range, fire rate, splash, slow, ground-only
    /// vs anti-air) come from TowerData, this ONE script drives all 4 tower
    /// types (Archer / Cannon / Mage / Ballista). Add a 5th tower by making a
    /// new TowerData asset - no code changes needed unless it needs a unique ability.
    /// </summary>
    public class Tower : MonoBehaviour
    {
        [SerializeField] private Transform firePoint;
        [SerializeField] private SpriteRenderer bodyRenderer; // swapped visually on upgrade if desired
        [SerializeField] private WaveManager waveManager; // assign in scene, or find via singleton/service locator

        public TowerData Data { get; private set; }
        public int CurrentLevel { get; private set; } // 0-based index into upgradeLevels
        public BuildSlot HomeSlot { get; private set; }

        private float _fireCooldown;
        private int _totalCoinsInvested;
        private TowerUpgradeLevel Stats => Data.GetLevel(CurrentLevel);

        public void Initialize(TowerData data, WaveManager wm, BuildSlot slot = null)
        {
            Data = data;
            CurrentLevel = 0;
            waveManager = wm;
            HomeSlot = slot;
            _totalCoinsInvested = data.buildCost;
        }

        /// <summary>Refunds a portion of invested coins and frees up the build slot.</summary>
        public void Sell()
        {
            int refund = Mathf.RoundToInt(_totalCoinsInvested * 0.6f);
            GameManager.Instance?.AddCoins(refund);
            HomeSlot?.Clear();
            Destroy(gameObject);
        }

        private void Update()
        {
            if (Data == null || waveManager == null) return;
            if (GameManager.Instance != null && GameManager.Instance.State != GameState.Playing) return;

            _fireCooldown -= Time.deltaTime;

            Enemy target = AcquireTarget();
            if (target != null && _fireCooldown <= 0f)
            {
                Fire(target);
                _fireCooldown = 1f / Mathf.Max(0.01f, Stats.fireRate);
            }
        }

        private Enemy AcquireTarget()
        {
            Enemy best = null;
            float bestScore = float.NegativeInfinity;

            foreach (Enemy enemy in waveManager.AliveEnemies)
            {
                if (enemy == null || enemy.IsDead) continue;
                if (enemy.IsFlying && !Stats.canHitFlying) continue;

                float dist = Vector3.Distance(transform.position, enemy.transform.position);
                if (dist > Stats.range) continue;

                float score = ScoreForPriority(enemy, dist);
                if (score > bestScore)
                {
                    bestScore = score;
                    best = enemy;
                }
            }
            return best;
        }

        private float ScoreForPriority(Enemy enemy, float distance)
        {
            PathFollower pf = enemy.GetComponent<PathFollower>();
            switch (Data.defaultPriority)
            {
                case TargetPriority.Closest:
                    return -distance;
                case TargetPriority.Strongest:
                    return enemy.CurrentHealth;
                case TargetPriority.Weakest:
                    return -enemy.CurrentHealth;
                case TargetPriority.First:
                default:
                    return pf != null ? pf.DistanceTraveled : -distance;
            }
        }

        private void Fire(Enemy target)
        {
            if (Data.projectilePrefab == null || ObjectPoolManager.Instance == null) return;

            Vector3 spawnPos = firePoint != null ? firePoint.position : transform.position;
            GameObject projObj = ObjectPoolManager.Instance.Spawn(Data.projectilePrefab, spawnPos, Quaternion.identity);
            Projectile proj = projObj.GetComponent<Projectile>();

            proj.Fire(target, Stats.damage, Data.hasSplashDamage, Data.splashRadius,
                      Data.appliesSlow, Data.slowMultiplier, Data.slowDuration, Data.projectilePrefab);
        }

        // ----- Upgrades -----
        public bool CanUpgrade => Data != null && CurrentLevel < Data.MaxLevel - 1;

        public int NextUpgradeCost => CanUpgrade ? Data.GetLevel(CurrentLevel + 1).upgradeCost : -1;

        public bool TryUpgrade()
        {
            if (!CanUpgrade) return false;

            int cost = NextUpgradeCost;
            if (GameManager.Instance == null || !GameManager.Instance.SpendCoins(cost)) return false;

            CurrentLevel++;
            _totalCoinsInvested += cost;

            TowerUpgradeLevel newStats = Stats;
            if (newStats.visualPrefab != null && bodyRenderer != null)
            {
                // Optional: swap sprite to reflect the tower's new tier
                SpriteRenderer newVisual = newStats.visualPrefab.GetComponent<SpriteRenderer>();
                if (newVisual != null) bodyRenderer.sprite = newVisual.sprite;
            }

            return true;
        }

        private void OnDrawGizmosSelected()
        {
            if (Data == null) return;
            Gizmos.color = new Color(0.2f, 0.8f, 1f, 0.35f);
            Gizmos.DrawWireSphere(transform.position, Stats.range);
        }
    }
}
