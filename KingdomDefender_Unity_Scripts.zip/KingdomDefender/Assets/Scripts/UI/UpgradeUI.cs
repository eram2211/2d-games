using UnityEngine;
using UnityEngine.UI;
using TMPro;
using KingdomDefender.Towers;

namespace KingdomDefender.UI
{
    /// <summary>
    /// Contextual panel that appears when the player selects a placed tower.
    /// Shows its name, current level, upgrade cost, and a sell button.
    /// Listens to TowerPlacement's selection events rather than polling.
    /// </summary>
    public class UpgradeUI : MonoBehaviour
    {
        [SerializeField] private GameObject panelRoot;
        [SerializeField] private TMP_Text towerNameText;
        [SerializeField] private TMP_Text levelText;
        [SerializeField] private TMP_Text upgradeCostText;
        [SerializeField] private Button upgradeButton;
        [SerializeField] private Button sellButton;
        [SerializeField] private TowerPlacement towerPlacement;

        private Tower _currentTower;

        private void Start()
        {
            panelRoot.SetActive(false);

            towerPlacement.OnTowerSelected += HandleTowerSelected;
            towerPlacement.OnSelectionCleared += HandleSelectionCleared;

            upgradeButton.onClick.AddListener(HandleUpgradeClicked);
            sellButton.onClick.AddListener(HandleSellClicked);
        }

        private void OnDestroy()
        {
            towerPlacement.OnTowerSelected -= HandleTowerSelected;
            towerPlacement.OnSelectionCleared -= HandleSelectionCleared;
        }

        private void HandleTowerSelected(Tower tower)
        {
            _currentTower = tower;
            panelRoot.SetActive(true);
            Refresh();
        }

        private void HandleSelectionCleared()
        {
            _currentTower = null;
            panelRoot.SetActive(false);
        }

        private void Refresh()
        {
            if (_currentTower == null) return;

            towerNameText.text = _currentTower.Data.towerName;
            levelText.text = $"Level {_currentTower.CurrentLevel + 1}";

            if (_currentTower.CanUpgrade)
            {
                upgradeButton.gameObject.SetActive(true);
                upgradeCostText.text = _currentTower.NextUpgradeCost.ToString();
            }
            else
            {
                upgradeButton.gameObject.SetActive(false);
                upgradeCostText.text = "MAX";
            }
        }

        private void HandleUpgradeClicked()
        {
            if (_currentTower != null && _currentTower.TryUpgrade())
            {
                Refresh();
            }
        }

        private void HandleSellClicked()
        {
            towerPlacement.SellSelectedTower();
        }
    }
}
