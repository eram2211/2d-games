using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using KingdomDefender.Core;
using KingdomDefender.Data;
using KingdomDefender.Towers;

namespace KingdomDefender.UI
{
    /// <summary>
    /// Populates the shop with one button per TowerData (the 4 tower types, or
    /// more if you add them). Clicking a button calls TowerPlacement.BeginPlacement.
    /// Buttons grey out automatically when the player can't afford that tower.
    /// </summary>
    public class ShopUI : MonoBehaviour
    {
        [System.Serializable]
        public class ShopSlot
        {
            public TowerData towerData;
            public Button button;
            public Image icon;
            public TMP_Text nameText;
            public TMP_Text costText;
        }

        [SerializeField] private List<ShopSlot> slots = new List<ShopSlot>();
        [SerializeField] private TowerPlacement towerPlacement;

        private void Start()
        {
            foreach (var slot in slots)
            {
                if (slot.icon != null && slot.towerData.icon != null) slot.icon.sprite = slot.towerData.icon;
                if (slot.nameText != null) slot.nameText.text = slot.towerData.towerName;
                if (slot.costText != null) slot.costText.text = slot.towerData.buildCost.ToString();

                TowerData capturedData = slot.towerData; // avoid closure bug
                slot.button.onClick.AddListener(() => towerPlacement.BeginPlacement(capturedData));
            }

            if (GameManager.Instance != null) GameManager.Instance.OnCoinsChanged += RefreshAffordability;
        }

        private void OnDestroy()
        {
            if (GameManager.Instance != null) GameManager.Instance.OnCoinsChanged -= RefreshAffordability;
        }

        private void RefreshAffordability(int currentCoins)
        {
            foreach (var slot in slots)
            {
                slot.button.interactable = currentCoins >= slot.towerData.buildCost;
            }
        }
    }
}
