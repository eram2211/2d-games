using UnityEngine;
using UnityEngine.UI;
using TMPro;
using KingdomDefender.Core;
using KingdomDefender.SaveSystem;

namespace KingdomDefender.UI
{
    /// <summary>
    /// Shown when the player successfully defends the castle through the final wave.
    /// </summary>
    public class VictoryUI : MonoBehaviour
    {
        [SerializeField] private GameObject panelRoot;
        [SerializeField] private TMP_Text finalScoreText;
        [SerializeField] private TMP_Text highScoreText;
        [SerializeField] private Button playAgainButton;
        [SerializeField] private Button mainMenuButton;
        [SerializeField] private string mainMenuSceneName = "MainMenu";

        private void Start()
        {
            panelRoot.SetActive(false);

            if (GameManager.Instance != null) GameManager.Instance.OnVictory += HandleVictory;

            playAgainButton.onClick.AddListener(() => GameManager.Instance.RestartLevel());
            mainMenuButton.onClick.AddListener(() => GameManager.Instance.ReturnToMainMenu(mainMenuSceneName));
        }

        private void OnDestroy()
        {
            if (GameManager.Instance != null) GameManager.Instance.OnVictory -= HandleVictory;
        }

        private void HandleVictory()
        {
            int score = GameManager.Instance.Score;
            int best = HighScoreManager.Instance != null ? HighScoreManager.Instance.HighScore : score;

            finalScoreText.text = $"Final Score: {score}";
            highScoreText.text = $"Best: {best}";

            panelRoot.SetActive(true);
        }
    }
}
