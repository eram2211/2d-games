using UnityEngine;
using UnityEngine.UI;
using TMPro;
using KingdomDefender.Core;
using KingdomDefender.SaveSystem;

namespace KingdomDefender.UI
{
    /// <summary>
    /// Shown when the castle's health hits 0. Displays final score and
    /// current best, offers Retry / Main Menu.
    /// </summary>
    public class GameOverUI : MonoBehaviour
    {
        [SerializeField] private GameObject panelRoot;
        [SerializeField] private TMP_Text finalScoreText;
        [SerializeField] private TMP_Text highScoreText;
        [SerializeField] private TMP_Text newRecordBadge;
        [SerializeField] private Button retryButton;
        [SerializeField] private Button mainMenuButton;
        [SerializeField] private string mainMenuSceneName = "MainMenu";

        private void Start()
        {
            panelRoot.SetActive(false);

            if (GameManager.Instance != null) GameManager.Instance.OnGameOver += HandleGameOver;

            retryButton.onClick.AddListener(() => GameManager.Instance.RestartLevel());
            mainMenuButton.onClick.AddListener(() => GameManager.Instance.ReturnToMainMenu(mainMenuSceneName));
        }

        private void OnDestroy()
        {
            if (GameManager.Instance != null) GameManager.Instance.OnGameOver -= HandleGameOver;
        }

        private void HandleGameOver()
        {
            int score = GameManager.Instance.Score;
            int best = HighScoreManager.Instance != null ? HighScoreManager.Instance.HighScore : score;

            finalScoreText.text = $"Score: {score}";
            highScoreText.text = $"Best: {best}";
            if (newRecordBadge != null) newRecordBadge.gameObject.SetActive(score >= best);

            panelRoot.SetActive(true);
        }
    }
}
