using UnityEngine;
using UnityEngine.UI;
using TMPro;
using KingdomDefender.Core;
using KingdomDefender.Castle;
using KingdomDefender.Waves;

namespace KingdomDefender.UI
{
    /// <summary>
    /// Wires up the persistent gameplay HUD: coin count, castle health bar,
    /// current wave / total waves, and the countdown to the next wave.
    /// Subscribes to events instead of polling so it only updates on change.
    /// </summary>
    public class UIManager : MonoBehaviour
    {
        [Header("Coins")]
        [SerializeField] private TMP_Text coinsText;

        [Header("Health")]
        [SerializeField] private Image healthFillImage;
        [SerializeField] private TMP_Text healthText;

        [Header("Wave")]
        [SerializeField] private TMP_Text waveText;
        [SerializeField] private TMP_Text nextWaveTimerText;
        [SerializeField] private GameObject bossWaveBanner;

        [Header("References")]
        [SerializeField] private CastleHealth castleHealth;
        [SerializeField] private WaveManager waveManager;

        private void OnEnable()
        {
            if (GameManager.Instance != null)
            {
                GameManager.Instance.OnCoinsChanged += UpdateCoins;
                UpdateCoins(GameManager.Instance.Coins);
            }

            if (castleHealth != null)
            {
                castleHealth.OnHealthChanged += UpdateHealth;
                UpdateHealth(castleHealth.CurrentHealth, castleHealth.MaxHealth);
            }

            if (waveManager != null)
            {
                waveManager.OnWaveStarted += UpdateWave;
            }
        }

        private void OnDisable()
        {
            if (GameManager.Instance != null) GameManager.Instance.OnCoinsChanged -= UpdateCoins;
            if (castleHealth != null) castleHealth.OnHealthChanged -= UpdateHealth;
            if (waveManager != null) waveManager.OnWaveStarted -= UpdateWave;
        }

        private void Update()
        {
            if (waveManager == null || nextWaveTimerText == null) return;

            if (waveManager.TimeUntilNextWave > 0f)
            {
                nextWaveTimerText.gameObject.SetActive(true);
                nextWaveTimerText.text = $"Next wave in {Mathf.CeilToInt(waveManager.TimeUntilNextWave)}s";
            }
            else
            {
                nextWaveTimerText.gameObject.SetActive(false);
            }

            if (bossWaveBanner != null)
            {
                bossWaveBanner.SetActive(waveManager.IsBossWaveIncoming && waveManager.TimeUntilNextWave > 0f);
            }
        }

        private void UpdateCoins(int amount)
        {
            if (coinsText != null) coinsText.text = amount.ToString();
        }

        private void UpdateHealth(int current, int max)
        {
            if (healthFillImage != null) healthFillImage.fillAmount = max > 0 ? (float)current / max : 0f;
            if (healthText != null) healthText.text = $"{current}/{max}";
        }

        private void UpdateWave(int waveNumber)
        {
            if (waveText != null) waveText.text = $"Wave {waveNumber}/{waveManager.TotalWaves}";
        }
    }
}
