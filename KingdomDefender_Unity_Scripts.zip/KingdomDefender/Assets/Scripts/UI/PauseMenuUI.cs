using UnityEngine;
using UnityEngine.UI;
using KingdomDefender.Core;

namespace KingdomDefender.UI
{
    /// <summary>
    /// Pause menu overlay. Toggled by ESC/back button or a pause icon in the HUD.
    /// Subscribes to GameManager.OnStateChanged so the panel shows/hides itself
    /// automatically whenever the state flips to/from Paused.
    /// </summary>
    public class PauseMenuUI : MonoBehaviour
    {
        [SerializeField] private GameObject panelRoot;
        [SerializeField] private Button resumeButton;
        [SerializeField] private Button restartButton;
        [SerializeField] private Button mainMenuButton;
        [SerializeField] private string mainMenuSceneName = "MainMenu";

        private void Start()
        {
            panelRoot.SetActive(false);

            if (GameManager.Instance != null) GameManager.Instance.OnStateChanged += HandleStateChanged;

            resumeButton.onClick.AddListener(() => GameManager.Instance.TogglePause());
            restartButton.onClick.AddListener(() => GameManager.Instance.RestartLevel());
            mainMenuButton.onClick.AddListener(() => GameManager.Instance.ReturnToMainMenu(mainMenuSceneName));
        }

        private void OnDestroy()
        {
            if (GameManager.Instance != null) GameManager.Instance.OnStateChanged -= HandleStateChanged;
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape) && GameManager.Instance != null)
            {
                if (GameManager.Instance.State == GameState.Playing || GameManager.Instance.State == GameState.Paused)
                {
                    GameManager.Instance.TogglePause();
                }
            }
        }

        private void HandleStateChanged(GameState state)
        {
            panelRoot.SetActive(state == GameState.Paused);
        }
    }
}
