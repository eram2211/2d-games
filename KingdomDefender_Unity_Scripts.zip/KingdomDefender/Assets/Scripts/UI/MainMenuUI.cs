using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
using KingdomDefender.SaveSystem;

namespace KingdomDefender.UI
{
    /// <summary>
    /// Controller for the Main Menu scene. Place a HighScoreManager and
    /// (optionally) a GameManager as persistent objects here too, or make sure
    /// they exist via DontDestroyOnLoad before this scene loads.
    /// </summary>
    public class MainMenuUI : MonoBehaviour
    {
        [SerializeField] private Button playButton;
        [SerializeField] private Button quitButton;
        [SerializeField] private TMP_Text highScoreText;
        [SerializeField] private string gameplaySceneName = "Gameplay";

        private void Start()
        {
            if (highScoreText != null)
            {
                int best = HighScoreManager.Instance != null ? HighScoreManager.Instance.HighScore : 0;
                highScoreText.text = $"High Score: {best}";
            }

            playButton.onClick.AddListener(PlayGame);
            if (quitButton != null) quitButton.onClick.AddListener(QuitGame);
        }

        private void PlayGame()
        {
            SceneManager.LoadScene(gameplaySceneName);
        }

        private void QuitGame()
        {
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }
    }
}
