using System;
using UnityEngine;
using KingdomDefender.Core;

namespace KingdomDefender.Castle
{
    /// <summary>
    /// The player's "lives" - every enemy that reaches the end of the path
    /// deals damage here. Reaching 0 triggers Game Over.
    /// </summary>
    public class CastleHealth : MonoBehaviour
    {
        public static CastleHealth Instance { get; private set; }

        [SerializeField] private int maxHealth = 20;
        public int MaxHealth => maxHealth;
        public int CurrentHealth { get; private set; }

        public event Action<int, int> OnHealthChanged; // current, max

        private void Awake()
        {
            Instance = this;
            CurrentHealth = maxHealth;
        }

        public void TakeDamage(int amount)
        {
            if (CurrentHealth <= 0) return;

            CurrentHealth = Mathf.Max(0, CurrentHealth - amount);
            OnHealthChanged?.Invoke(CurrentHealth, maxHealth);

            if (CurrentHealth <= 0)
            {
                GameManager.Instance?.SetState(GameState.GameOver);
            }
        }

        public void ResetHealth()
        {
            CurrentHealth = maxHealth;
            OnHealthChanged?.Invoke(CurrentHealth, maxHealth);
        }
    }
}
