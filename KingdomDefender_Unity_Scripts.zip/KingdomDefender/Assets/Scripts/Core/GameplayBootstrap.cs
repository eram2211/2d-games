using UnityEngine;

namespace KingdomDefender.Core
{
    /// <summary>
    /// Drop this on an empty GameObject in the Gameplay scene. Ensures a
    /// GameManager and HighScoreManager exist (in case the player launched
    /// straight into this scene from the editor) and kicks off StartNewGame().
    /// </summary>
    public class GameplayBootstrap : MonoBehaviour
    {
        [SerializeField] private GameManager gameManagerPrefab;
        [SerializeField] private KingdomDefender.SaveSystem.HighScoreManager highScoreManagerPrefab;

        private void Awake()
        {
            if (GameManager.Instance == null && gameManagerPrefab != null)
            {
                Instantiate(gameManagerPrefab);
            }

            if (KingdomDefender.SaveSystem.HighScoreManager.Instance == null && highScoreManagerPrefab != null)
            {
                Instantiate(highScoreManagerPrefab);
            }
        }

        private void Start()
        {
            GameManager.Instance?.StartNewGame();
        }
    }
}
