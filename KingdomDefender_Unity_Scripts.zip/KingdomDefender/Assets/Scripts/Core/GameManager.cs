using System;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace KingdomDefender.Core
{
    public enum GameState { MainMenu, Playing, Paused, GameOver, Victory }

    /// <summary>
    /// The single source of truth for run-time game state: coins, current game state,
    /// score, and transitions between Playing / Paused / GameOver / Victory.
    /// Persists across the gameplay scene only (destroyed when returning to Main Menu scene
    /// is optional - here we keep it simple and let it live for the whole app via DontDestroyOnLoad).
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        [Header("Starting values")]
        [SerializeField] private int startingCoins = 150;

        public int Coins { get; private set; }
        public int Score { get; private set; }
        public GameState State { get; private set; } = GameState.MainMenu;

        // Events the UI / other systems subscribe to instead of polling every frame.
        public event Action<int> OnCoinsChanged;
        public event Action<GameState> OnStateChanged;
        public event Action OnGameOver;
        public event Action OnVictory;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

        public void StartNewGame()
        {
            Coins = startingCoins;
            Score = 0;
            SetState(GameState.Playing);
            Time.timeScale = 1f;
            OnCoinsChanged?.Invoke(Coins);
        }

        public bool SpendCoins(int amount)
        {
            if (amount <= 0) return true;
            if (Coins < amount) return false;
            Coins -= amount;
            OnCoinsChanged?.Invoke(Coins);
            return true;
        }

        public void AddCoins(int amount)
        {
            Coins += amount;
            OnCoinsChanged?.Invoke(Coins);
        }

        public void AddScore(int amount)
        {
            Score += amount;
        }

        public void SetState(GameState newState)
        {
            State = newState;
            OnStateChanged?.Invoke(newState);

            switch (newState)
            {
                case GameState.Paused:
                    Time.timeScale = 0f;
                    break;
                case GameState.Playing:
                    Time.timeScale = 1f;
                    break;
                case GameState.GameOver:
                    Time.timeScale = 0f;
                    HighScoreManagerAccessor.SaveIfHighScore(Score);
                    OnGameOver?.Invoke();
                    break;
                case GameState.Victory:
                    Time.timeScale = 0f;
                    HighScoreManagerAccessor.SaveIfHighScore(Score);
                    OnVictory?.Invoke();
                    break;
            }
        }

        public void TogglePause()
        {
            if (State == GameState.Playing) SetState(GameState.Paused);
            else if (State == GameState.Paused) SetState(GameState.Playing);
        }

        public void ReturnToMainMenu(string mainMenuSceneName = "MainMenu")
        {
            Time.timeScale = 1f;
            SetState(GameState.MainMenu);
            SceneManager.LoadScene(mainMenuSceneName);
        }

        public void RestartLevel()
        {
            Time.timeScale = 1f;
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    /// <summary>
    /// Small indirection so GameManager doesn't need a hard reference to the
    /// SaveSystem namespace at compile time in this file ordering; simply
    /// forwards to HighScoreManager.Instance.
    /// </summary>
    internal static class HighScoreManagerAccessor
    {
        public static void SaveIfHighScore(int score)
        {
            var mgr = KingdomDefender.SaveSystem.HighScoreManager.Instance;
            if (mgr != null) mgr.TrySaveHighScore(score);
        }
    }
}
