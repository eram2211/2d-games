using System.Collections.Generic;
using UnityEngine;

namespace KingdomDefender.Core
{
    /// <summary>
    /// Singleton that owns every ObjectPool in the game, keyed by prefab.
    /// Enemies, projectiles and hit-VFX are all requested through here so
    /// spawning during a 50-enemy boss wave never allocates/destroys GameObjects.
    /// </summary>
    public class ObjectPoolManager : MonoBehaviour
    {
        public static ObjectPoolManager Instance { get; private set; }

        [System.Serializable]
        public class PoolDefinition
        {
            public GameObject prefab;
            public int prewarmCount = 10;
        }

        [Header("Pools to prewarm at startup")]
        [SerializeField] private List<PoolDefinition> poolDefinitions = new List<PoolDefinition>();

        private readonly Dictionary<GameObject, ObjectPool> _pools = new Dictionary<GameObject, ObjectPool>();

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;

            foreach (var def in poolDefinitions)
            {
                RegisterPool(def.prefab, def.prewarmCount);
            }
        }

        public void RegisterPool(GameObject prefab, int prewarmCount)
        {
            if (prefab == null || _pools.ContainsKey(prefab)) return;
            _pools[prefab] = new ObjectPool(prefab, prewarmCount, transform);
        }

        public GameObject Spawn(GameObject prefab, Vector3 position, Quaternion rotation)
        {
            if (!_pools.ContainsKey(prefab))
            {
                RegisterPool(prefab, 5);
            }
            return _pools[prefab].Get(position, rotation);
        }

        public void Return(GameObject prefab, GameObject instance)
        {
            if (_pools.TryGetValue(prefab, out ObjectPool pool))
            {
                pool.Return(instance);
            }
            else
            {
                Destroy(instance); // fallback safety net
            }
        }
    }
}
