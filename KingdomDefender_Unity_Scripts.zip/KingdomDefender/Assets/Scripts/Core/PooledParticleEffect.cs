using UnityEngine;

namespace KingdomDefender.Core
{
    /// <summary>
    /// Attach to any particle-effect prefab (hit sparks, death burst, tower muzzle
    /// flash, coin pickup pop) that is spawned via ObjectPoolManager.Spawn(...).
    /// Automatically returns itself to the pool once the ParticleSystem finishes,
    /// so effects never need Destroy() and never leak.
    /// </summary>
    [RequireComponent(typeof(ParticleSystem))]
    public class PooledParticleEffect : MonoBehaviour, IPoolable
    {
        private ParticleSystem _ps;
        private ObjectPool _pool;
        private GameObject _sourcePrefab;
        private float _timer;

        private void Awake()
        {
            _ps = GetComponent<ParticleSystem>();
        }

        public void SetPool(ObjectPool pool) => _pool = pool;

        public void OnSpawn()
        {
            _timer = 0f;
            _ps.Clear();
            _ps.Play();
        }

        private void Update()
        {
            if (!_ps.IsAlive())
            {
                ReturnToPool();
            }
        }

        public void ReturnToPool()
        {
            if (_pool != null) _pool.Return(gameObject);
            else if (ObjectPoolManager.Instance != null && _sourcePrefab != null)
                ObjectPoolManager.Instance.Return(_sourcePrefab, gameObject);
            else
                Destroy(gameObject);
        }
    }
}
