using System.Collections.Generic;
using UnityEngine;

namespace KingdomDefender.Core
{
    /// <summary>
    /// Generic, reusable object pool. Attach one ObjectPoolManager to the scene
    /// and register prefabs (enemies, projectiles, hit-particles, coin popups, etc.)
    /// so nothing is Instantiate()/Destroy()'d at runtime -> zero GC spikes during waves.
    /// </summary>
    public class ObjectPool
    {
        private readonly GameObject _prefab;
        private readonly Transform _parent;
        private readonly Queue<GameObject> _available = new Queue<GameObject>();

        public ObjectPool(GameObject prefab, int prewarmCount, Transform parent)
        {
            _prefab = prefab;
            _parent = parent;

            for (int i = 0; i < prewarmCount; i++)
            {
                GameObject obj = CreateNew();
                obj.SetActive(false);
                _available.Enqueue(obj);
            }
        }

        private GameObject CreateNew()
        {
            GameObject obj = Object.Instantiate(_prefab, _parent);
            IPoolable poolable = obj.GetComponent<IPoolable>();
            poolable?.SetPool(this);
            return obj;
        }

        public GameObject Get(Vector3 position, Quaternion rotation)
        {
            GameObject obj = _available.Count > 0 ? _available.Dequeue() : CreateNew();
            obj.transform.SetPositionAndRotation(position, rotation);
            obj.SetActive(true);

            IPoolable poolable = obj.GetComponent<IPoolable>();
            poolable?.OnSpawn();

            return obj;
        }

        public void Return(GameObject obj)
        {
            obj.SetActive(false);
            _available.Enqueue(obj);
        }
    }

    /// <summary>
    /// Implement on any pooled object (Enemy, Projectile, ParticleFX) so it can
    /// return itself to its pool instead of being destroyed.
    /// </summary>
    public interface IPoolable
    {
        void SetPool(ObjectPool pool);
        void OnSpawn();
        void ReturnToPool();
    }
}
