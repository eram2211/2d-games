using UnityEngine;

namespace KingdomDefender.Environment
{
    /// <summary>
    /// Purely cosmetic day/night cycle: smoothly tints a global light (2D URP
    /// Global Light or any SpriteRenderer used as a screen-space overlay) and
    /// ambient color across a repeating cycle. Does not affect gameplay balance -
    /// swap the color gradient for something spookier if night should hint at
    /// tougher waves.
    /// </summary>
    public class DayNightCycle : MonoBehaviour
    {
        [SerializeField] private SpriteRenderer overlayRenderer; // full-screen sprite tinted per time-of-day
        [SerializeField] private Gradient dayNightGradient; // configure Dawn -> Day -> Dusk -> Night -> Dawn in inspector
        [SerializeField] private float cycleDurationSeconds = 120f;
        [SerializeField] private bool pauseDuringPause = true;

        private float _time;

        private void Update()
        {
            if (pauseDuringPause && Time.timeScale == 0f) return;

            _time += Time.deltaTime;
            float t = (_time % cycleDurationSeconds) / cycleDurationSeconds;

            if (overlayRenderer != null && dayNightGradient != null)
            {
                Color c = dayNightGradient.Evaluate(t);
                overlayRenderer.color = c;
            }
        }

        /// <summary>0 = start of cycle (dawn), 1 = full cycle complete. Useful if other
        /// systems (e.g. nocturnal enemy spawns) want to react to time of day.</summary>
        public float NormalizedTime => cycleDurationSeconds > 0f ? (_time % cycleDurationSeconds) / cycleDurationSeconds : 0f;
    }
}
