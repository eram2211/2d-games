# Kingdom Defender — 2D Tower Defense (Unity C#)

This package contains complete, compile-ready C# scripts for a full tower-defense
game. It's organized as a drop-in `Assets/Scripts` folder — copy it into a Unity
2021 LTS+ project (2D URP template recommended) and follow the setup steps below.
TextMeshPro is used for all UI text (Unity will prompt to import TMP Essentials
the first time you open a scene that uses it — accept it).

## Folder structure

```
Assets/Scripts/
  Core/         GameManager, ObjectPool(+Manager), GameplayBootstrap, PooledParticleEffect
  Data/         EnemyData, TowerData  (ScriptableObjects — this is what makes adding
                content "just data", no new code needed)
  Enemies/      Enemy, PathFollower, PathWaypoints, EnemyHealthBar
  Towers/       Tower, Projectile, TowerPlacement, BuildSlot
  Waves/        WaveManager, WaveData
  Castle/       CastleHealth
  UI/           UIManager, ShopUI, UpgradeUI, PauseMenuUI, GameOverUI, VictoryUI, MainMenuUI
  Environment/  DayNightCycle
  SaveSystem/   HighScoreManager
```

## How the systems fit together

- **Data-driven content** (`Data/EnemyData.cs`, `Data/TowerData.cs`): every enemy
  and tower's stats live in a ScriptableObject asset, not in code. To add a 6th
  enemy or 5th tower, right-click in the Project window →
  `Create > KingdomDefender > Enemy Data` / `Tower Data`, fill in the fields, and
  drop the asset into the WaveManager / ShopUI lists. No script changes required.

- **Object pooling** (`Core/ObjectPool.cs`, `Core/ObjectPoolManager.cs`): one
  manager owns a pool per prefab (enemies, projectiles, particle effects).
  `Enemy`, `Projectile`, and `PooledParticleEffect` all implement `IPoolable` and
  return themselves instead of calling `Destroy()`. This is what keeps 50-enemy
  boss waves from causing GC/instantiate spikes.

- **Enemy AI** (`Enemies/PathFollower.cs`): moves along a `PathWaypoints` route.
  Ground, Tank, and Flying enemies are all the *same* component — the
  `EnemyMovementType` enum on `EnemyData` controls speed, hover height, and
  whether ground-only towers can target it (`TowerData.canHitFlying` per
  upgrade level).

- **Towers** (`Towers/Tower.cs`): one script drives all 4 tower types (Archer,
  Cannon, Mage, Ballista) because damage/range/fire-rate/splash/slow all come
  from `TowerData`. Targeting priority (First / Closest / Strongest / Weakest)
  is also data-driven.

- **Waves & bosses** (`Waves/WaveManager.cs`): runs a coroutine loop — prep
  timer → spawn wave → wait for all enemies cleared → repeat. Every 5th wave
  (configurable via `bossWaveInterval`) spawns a boss + escort group. You can
  either hand-author waves as `WaveData` assets or let it fall back to
  procedural scaling (`enemyCount = 5 + wave*2`, spawn interval shrinks slightly
  each wave).

- **UI**: `ShopUI` lists towers with live afford/can't-afford states,
  `UpgradeUI` shows upgrade cost + sell for the selected tower, `UIManager`
  drives coins/health/wave HUD via events (no polling), `PauseMenuUI` /
  `GameOverUI` / `VictoryUI` subscribe to `GameManager`'s state-change events
  and show themselves automatically.

- **Save system** (`SaveSystem/HighScoreManager.cs`): PlayerPrefs-backed, only
  writes when the new score beats the old one.

## Scene setup checklist

1. **MainMenu scene**: Canvas with Play/Quit buttons + high score text →
   `MainMenuUI`. Add a `HighScoreManager` (and `GameManager`, if you want coins
   to persist oddly across menu — otherwise just let Gameplay scene create it).

2. **Gameplay scene**:
   - Empty GameObject with `GameplayBootstrap` (assign GameManager +
     HighScoreManager prefabs if they don't already exist as persistent
     singletons).
   - `ObjectPoolManager` in the scene, prewarm-registered with your enemy,
     projectile, and particle-effect prefabs.
   - A `PathWaypoints` object with child Transforms marking the enemy route.
   - Several `BuildSlot` GameObjects (with a 2D trigger collider on a
     "BuildSlots" layer) off the path.
   - `WaveManager` with the path, spawn point, and your `EnemyData` list wired
     in (plus optional hand-authored `WaveData` assets).
   - `CastleHealth` on the castle object at the end of the path.
   - `TowerPlacement` with layer masks for BuildSlots and PlacedTowers, and a
     ghost-preview prefab.
   - Canvas with `UIManager`, `ShopUI`, `UpgradeUI`, `PauseMenuUI`,
     `GameOverUI`, `VictoryUI` wired to their respective UI elements.
   - Optional `DayNightCycle` on a full-screen overlay sprite for atmosphere.

3. **Prefabs you'll need to build in the editor** (art/animation not included —
   this package is the programming layer):
   - 5 enemy prefabs (Goblin, Orc, Wraith [flying], Troll [tank], Dark Knight
     [boss]) each with `Enemy` + `PathFollower` + `Animator` (Walk/Hit/Die
     states) + a world-space `EnemyHealthBar` canvas child.
   - 4 tower prefabs (Archer, Cannon, Mage, Ballista) each with `Tower` +
     a fire point child transform.
   - Matching `EnemyData` / `TowerData` ScriptableObject assets referencing
     those prefabs.
   - Projectile prefabs (arrow, cannonball, magic bolt, ballista spear) with
     `Projectile`.
   - Particle prefabs for hit/death/impact with `PooledParticleEffect`.

## Balancing knobs

Everything a designer would want to tweak lives in the Inspector: `EnemyData`
(HP/speed/resistance/reward), `TowerData.upgradeLevels[]` (damage/range/fire
rate per tier + cost), and `WaveManager` (totalWaves, bossWaveInterval,
timeBetweenWaves, baseSpawnInterval). No code changes needed for standard
balance passes.
