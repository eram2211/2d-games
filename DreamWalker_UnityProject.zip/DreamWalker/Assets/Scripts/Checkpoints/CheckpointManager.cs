using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Tracks the currently active checkpoint and respawns the player there on death.
/// </summary>
public class CheckpointManager : MonoBehaviour
{
    [SerializeField] private PlayerHealth _playerHealth;

    private readonly Dictionary<string, Vector2> _knownCheckpoints = new Dictionary<string, Vector2>();
    public string CurrentCheckpointId { get; private set; }
    private Vector2 _currentPosition;

    private void OnEnable() => GameEvents.OnPlayerDied += HandlePlayerDied;
    private void OnDisable() => GameEvents.OnPlayerDied -= HandlePlayerDied;

    public void SetCurrentCheckpoint(string id, Vector2 position)
    {
        CurrentCheckpointId = id;
        _currentPosition = position;
        _knownCheckpoints[id] = position;
    }

    /// <summary>Used by SaveLoadManager when restoring a checkpoint id without a fresh trigger hit.</summary>
    public void SetCurrentCheckpoint(string id)
    {
        CurrentCheckpointId = id;
        if (_knownCheckpoints.TryGetValue(id, out var pos))
            _currentPosition = pos;
    }

    private void HandlePlayerDied()
    {
        // Small delay lets death animation/SFX play before respawn; adjust to taste.
        Invoke(nameof(RespawnPlayer), 1.2f);
    }

    private void RespawnPlayer()
    {
        _playerHealth.RespawnAt(_currentPosition);
    }
}
