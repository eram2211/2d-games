using UnityEngine;

/// <summary>
/// A trigger placed in the level. When the player touches it, it becomes the
/// active respawn point and (optionally) auto-saves.
/// </summary>
[RequireComponent(typeof(Collider2D))]
public class Checkpoint : MonoBehaviour
{
    [SerializeField] private string _checkpointId;
    [SerializeField] private bool _autoSaveOnReach = true;
    public string CheckpointId => _checkpointId;

    private void Reset() => GetComponent<Collider2D>().isTrigger = true;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;

        GameManager.Instance.Checkpoints.SetCurrentCheckpoint(_checkpointId, transform.position);
        GameEvents.RaiseCheckpointReached(this);
        AudioManager.Instance?.PlaySfx("checkpoint");

        if (_autoSaveOnReach)
            GameManager.Instance.SaveLoad.Save();
    }
}
