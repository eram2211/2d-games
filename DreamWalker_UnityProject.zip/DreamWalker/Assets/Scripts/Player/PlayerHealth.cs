using UnityEngine;

/// <summary>
/// Player health/damage/respawn handling. Broadcasts changes via GameEvents so
/// UI, audio and checkpoint systems can react without a direct reference.
/// </summary>
public class PlayerHealth : MonoBehaviour
{
    [SerializeField] private float _maxHealth = 100f;
    [SerializeField] private float _invulnerabilityTime = 1f;

    private float _currentHealth;
    private float _invulnTimer;
    private PlayerController _controller;

    private void Awake()
    {
        _controller = GetComponent<PlayerController>();
        _currentHealth = _maxHealth;
    }

    private void Start()
    {
        GameEvents.RaisePlayerHealthChanged(_currentHealth, _maxHealth);
    }

    private void Update()
    {
        if (_invulnTimer > 0f) _invulnTimer -= Time.deltaTime;
    }

    public void TakeDamage(float amount)
    {
        if (_invulnTimer > 0f) return;

        _currentHealth = Mathf.Max(0, _currentHealth - amount);
        _invulnTimer = _invulnerabilityTime;
        GameEvents.RaisePlayerHealthChanged(_currentHealth, _maxHealth);

        if (_currentHealth <= 0f)
        {
            Die();
        }
        else
        {
            _controller.StateMachine.ChangeState<PlayerHurtState>();
        }
    }

    public void Heal(float amount)
    {
        _currentHealth = Mathf.Min(_maxHealth, _currentHealth + amount);
        GameEvents.RaisePlayerHealthChanged(_currentHealth, _maxHealth);
    }

    private void Die()
    {
        GameEvents.RaisePlayerDied();
        // CheckpointManager listens for this via GameManager flow and handles respawn/game over UI.
    }

    public void RespawnAt(Vector2 position)
    {
        _currentHealth = _maxHealth;
        transform.position = position;
        GameEvents.RaisePlayerHealthChanged(_currentHealth, _maxHealth);
        GameEvents.RaisePlayerRespawn(position);
    }

    public float CurrentHealth => _currentHealth;
    public float MaxHealth => _maxHealth;
}
