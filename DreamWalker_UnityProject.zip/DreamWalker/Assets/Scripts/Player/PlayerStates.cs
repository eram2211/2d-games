using UnityEngine;

/// <summary>
/// Concrete player states. Kept in one file for readability since each is small;
/// split into separate files if they grow. All implement IState via StateMachine.
/// </summary>

public abstract class PlayerStateBase : IState
{
    protected readonly PlayerController player;
    protected PlayerStateBase(PlayerController player) { this.player = player; }
    public virtual void Enter() { }
    public virtual void Tick() { }
    public virtual void FixedTick() { }
    public virtual void Exit() { }
}

public class PlayerIdleState : PlayerStateBase
{
    public PlayerIdleState(PlayerController p) : base(p) { }

    public override void Enter() => player.Animator?.Play("Idle");

    public override void Tick()
    {
        if (!player.IsGrounded) { player.StateMachine.ChangeState<PlayerFallState>(); return; }
        if (player.JumpPressed) { player.StateMachine.ChangeState<PlayerJumpState>(); return; }
        if (Mathf.Abs(player.HorizontalInput) > 0.01f) { player.StateMachine.ChangeState<PlayerRunState>(); return; }

        player.Move(0);
    }
}

public class PlayerRunState : PlayerStateBase
{
    public PlayerRunState(PlayerController p) : base(p) { }

    public override void Enter() => player.Animator?.Play("Run");

    public override void Tick()
    {
        if (!player.IsGrounded) { player.StateMachine.ChangeState<PlayerFallState>(); return; }
        if (player.JumpPressed) { player.StateMachine.ChangeState<PlayerJumpState>(); return; }
        if (Mathf.Abs(player.HorizontalInput) < 0.01f) { player.StateMachine.ChangeState<PlayerIdleState>(); return; }

        player.Move(player.HorizontalInput);
    }
}

public class PlayerJumpState : PlayerStateBase
{
    public PlayerJumpState(PlayerController p) : base(p) { }

    public override void Enter()
    {
        player.Animator?.Play("Jump");
        player.Jump();
        AudioManager.Instance?.PlaySfx("jump");
    }

    public override void Tick()
    {
        player.Move(player.HorizontalInput);
        if (player.Body.linearVelocity.y <= 0f)
            player.StateMachine.ChangeState<PlayerFallState>();
    }
}

public class PlayerFallState : PlayerStateBase
{
    public PlayerFallState(PlayerController p) : base(p) { }

    public override void Enter() => player.Animator?.Play("Fall");

    public override void Tick()
    {
        player.Move(player.HorizontalInput);
        if (player.IsGrounded)
            player.StateMachine.ChangeState<PlayerIdleState>();
    }
}

public class PlayerHurtState : PlayerStateBase
{
    private float _timer;
    private const float HurtDuration = 0.4f;

    public PlayerHurtState(PlayerController p) : base(p) { }

    public override void Enter()
    {
        _timer = HurtDuration;
        player.Animator?.Play("Hurt");
        AudioManager.Instance?.PlaySfx("hurt");
    }

    public override void Tick()
    {
        _timer -= Time.deltaTime;
        if (_timer <= 0f)
            player.StateMachine.ChangeState(player.IsGrounded ? (IState)new PlayerIdleState(player) : new PlayerFallState(player));
    }
}
