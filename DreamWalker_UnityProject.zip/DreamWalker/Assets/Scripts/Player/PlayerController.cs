using UnityEngine;

/// <summary>
/// Core player movement/physics. World-specific tuning (speed, jump, gravity) is injected
/// by DreamWorldManager via ApplyWorldModifiers rather than hardcoded here, so this script
/// stays reusable across all five dream worlds. Delegates animation/behaviour "mode" to a
/// StateMachine of PlayerState objects (Idle/Run/Jump/Fall/Hurt).
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public class PlayerController : MonoBehaviour
{
    [Header("Base Stats (unmodified by dream world)")]
    public float baseMoveSpeed = 6f;
    public float baseJumpForce = 12f;
    public float baseGravityScale = 3f;

    [Header("Ground Check")]
    public Transform groundCheck;
    public LayerMask groundLayer;
    public float groundCheckRadius = 0.15f;

    [Header("Footsteps")]
    public FootstepController footsteps;

    // Runtime, world-modified values
    private float _moveSpeedMult = 1f;
    private float _jumpForceMult = 1f;
    private float _gravityMult = 1f;

    public Rigidbody2D Body { get; private set; }
    public Animator Animator { get; private set; }
    public StateMachine StateMachine { get; private set; }
    public bool IsGrounded { get; private set; }
    public float HorizontalInput { get; private set; }
    public bool JumpPressed { get; private set; }

    private void Awake()
    {
        Body = GetComponent<Rigidbody2D>();
        Animator = GetComponent<Animator>();
        StateMachine = new StateMachine();

        StateMachine.RegisterState(new PlayerIdleState(this));
        StateMachine.RegisterState(new PlayerRunState(this));
        StateMachine.RegisterState(new PlayerJumpState(this));
        StateMachine.RegisterState(new PlayerFallState(this));
        StateMachine.RegisterState(new PlayerHurtState(this));
    }

    private void Start()
    {
        StateMachine.ChangeState<PlayerIdleState>();
    }

    private void Update()
    {
        HorizontalInput = Input.GetAxisRaw("Horizontal");
        JumpPressed = Input.GetButtonDown("Jump");
        IsGrounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);

        StateMachine.Tick();
    }

    private void FixedUpdate()
    {
        StateMachine.FixedTick();
    }

    /// <summary>Called by DreamWorldManager when a world is entered.</summary>
    public void ApplyWorldModifiers(float moveMult, float jumpMult, float gravityMult)
    {
        _moveSpeedMult = moveMult;
        _jumpForceMult = jumpMult;
        _gravityMult = gravityMult;
        Body.gravityScale = baseGravityScale * _gravityMult;
    }

    public float CurrentMoveSpeed => baseMoveSpeed * _moveSpeedMult;
    public float CurrentJumpForce => baseJumpForce * _jumpForceMult;

    public void Move(float horizontal)
    {
        Body.linearVelocity = new Vector2(horizontal * CurrentMoveSpeed, Body.linearVelocity.y);
        if (horizontal != 0)
        {
            transform.localScale = new Vector3(Mathf.Sign(horizontal), 1, 1);
            footsteps?.NotifyMoving(IsGrounded);
        }
        else
        {
            footsteps?.NotifyIdle();
        }
    }

    public void Jump()
    {
        Body.linearVelocity = new Vector2(Body.linearVelocity.x, CurrentJumpForce);
    }

    private void OnDrawGizmosSelected()
    {
        if (groundCheck == null) return;
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(groundCheck.position, groundCheckRadius);
    }
}
