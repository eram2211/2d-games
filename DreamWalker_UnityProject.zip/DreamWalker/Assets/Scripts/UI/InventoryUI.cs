using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Renders the player's collected items and fragment count. Spawns a simple slot
/// prefab per unique item; keep the prefab minimal (icon + count text).
/// </summary>
public class InventoryUI : MonoBehaviour
{
    [SerializeField] private InventorySystem inventory;
    [SerializeField] private Transform slotContainer;
    [SerializeField] private InventorySlotUI slotPrefab;
    [SerializeField] private List<ItemSO> knownItemDefs; // used to resolve icons by id

    private readonly Dictionary<string, InventorySlotUI> _activeSlots = new Dictionary<string, InventorySlotUI>();

    private void OnEnable()
    {
        inventory.OnInventoryChanged += Refresh;
        Refresh();
    }

    private void OnDisable() => inventory.OnInventoryChanged -= Refresh;

    private void Refresh()
    {
        foreach (var item in knownItemDefs)
        {
            int count = inventory.GetCount(item.itemId);
            if (count <= 0)
            {
                if (_activeSlots.TryGetValue(item.itemId, out var existing))
                {
                    Destroy(existing.gameObject);
                    _activeSlots.Remove(item.itemId);
                }
                continue;
            }

            if (!_activeSlots.TryGetValue(item.itemId, out var slot))
            {
                slot = Instantiate(slotPrefab, slotContainer);
                _activeSlots[item.itemId] = slot;
            }
            slot.Set(item.icon, count);
        }
    }
}
