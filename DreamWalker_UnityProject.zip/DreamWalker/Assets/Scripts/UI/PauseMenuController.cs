using UnityEngine;

/// <summary>
/// Toggles the pause panel and wires its buttons: Resume, Save, Settings, Main Menu.
/// </summary>
public class PauseMenuController : MonoBehaviour
{
    [SerializeField] private GameObject pausePanel;

    private void OnEnable() => GameEvents.OnGamePaused += HandlePauseChanged;
    private void OnDisable() => GameEvents.OnGamePaused -= HandlePauseChanged;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape) && GameManager.Instance.CurrentFlow != GameManager.Flow.MainMenu)
            GameManager.Instance.TogglePause();
    }

    private void HandlePauseChanged(bool paused) => pausePanel.SetActive(paused);

    public void OnResume() => GameManager.Instance.TogglePause();
    public void OnSave() => GameManager.Instance.SaveLoad.Save();
    public void OnMainMenu() => GameManager.Instance.ReturnToMainMenu();
}
