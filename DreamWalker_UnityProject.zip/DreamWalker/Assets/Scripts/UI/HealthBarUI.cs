using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Listens to GameEvents.OnPlayerHealthChanged and animates a fill-image health bar.
/// </summary>
public class HealthBarUI : MonoBehaviour
{
    [SerializeField] private Image fillImage;
    [SerializeField] private float lerpSpeed = 4f;
    private float _targetFill = 1f;

    private void OnEnable() => GameEvents.OnPlayerHealthChanged += HandleHealthChanged;
    private void OnDisable() => GameEvents.OnPlayerHealthChanged -= HandleHealthChanged;

    private void HandleHealthChanged(float current, float max) => _targetFill = max > 0 ? current / max : 0;

    private void Update()
    {
        fillImage.fillAmount = Mathf.Lerp(fillImage.fillAmount, _targetFill, Time.deltaTime * lerpSpeed);
    }
}
