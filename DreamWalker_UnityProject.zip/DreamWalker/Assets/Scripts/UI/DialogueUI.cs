using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// Renders the current dialogue line and, if present, choice buttons.
/// Kept dumb on purpose: DialogueManager owns all conversation logic and just tells
/// this script what to display.
/// </summary>
public class DialogueUI : MonoBehaviour
{
    [SerializeField] private GameObject root;
    [SerializeField] private TMP_Text speakerText;
    [SerializeField] private TMP_Text bodyText;
    [SerializeField] private Transform choiceButtonContainer;
    [SerializeField] private Button choiceButtonPrefab;
    [SerializeField] private Button continuePrompt; // shown when there are no choices

    private readonly List<GameObject> _spawnedButtons = new List<GameObject>();

    public void DisplayLine(DialogueSO.DialogueLine line, Action<DialogueSO.Choice> onChoice, Action onAutoAdvance)
    {
        root.SetActive(true);
        speakerText.text = line.speakerName;
        bodyText.text = line.text;

        ClearButtons();

        if (line.choices != null && line.choices.Length > 0)
        {
            continuePrompt.gameObject.SetActive(false);
            foreach (var choice in line.choices)
            {
                var btn = Instantiate(choiceButtonPrefab, choiceButtonContainer);
                btn.GetComponentInChildren<TMP_Text>().text = choice.choiceText;
                btn.onClick.AddListener(() => onChoice(choice));
                _spawnedButtons.Add(btn.gameObject);
            }
        }
        else
        {
            continuePrompt.gameObject.SetActive(true);
            continuePrompt.onClick.RemoveAllListeners();
            continuePrompt.onClick.AddListener(() => onAutoAdvance());
        }
    }

    private void ClearButtons()
    {
        foreach (var b in _spawnedButtons) Destroy(b);
        _spawnedButtons.Clear();
    }

    public void Hide()
    {
        root.SetActive(false);
        ClearButtons();
    }
}
