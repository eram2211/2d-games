using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Drives the Settings panel: master/music/sfx volume sliders, fullscreen toggle,
/// resolution dropdown. Persists to PlayerPrefs so choices survive between sessions.
/// </summary>
public class SettingsController : MonoBehaviour
{
    [SerializeField] private Slider masterSlider;
    [SerializeField] private Slider musicSlider;
    [SerializeField] private Slider sfxSlider;
    [SerializeField] private Toggle fullscreenToggle;

    private const string MasterKey = "vol_master";
    private const string MusicKey = "vol_music";
    private const string SfxKey = "vol_sfx";
    private const string FullscreenKey = "fullscreen";

    private void OnEnable()
    {
        masterSlider.value = PlayerPrefs.GetFloat(MasterKey, 1f);
        musicSlider.value = PlayerPrefs.GetFloat(MusicKey, 0.8f);
        sfxSlider.value = PlayerPrefs.GetFloat(SfxKey, 1f);
        fullscreenToggle.isOn = PlayerPrefs.GetInt(FullscreenKey, 1) == 1;

        masterSlider.onValueChanged.AddListener(SetMaster);
        musicSlider.onValueChanged.AddListener(SetMusic);
        sfxSlider.onValueChanged.AddListener(SetSfx);
        fullscreenToggle.onValueChanged.AddListener(SetFullscreen);
    }

    private void OnDisable()
    {
        masterSlider.onValueChanged.RemoveListener(SetMaster);
        musicSlider.onValueChanged.RemoveListener(SetMusic);
        sfxSlider.onValueChanged.RemoveListener(SetSfx);
        fullscreenToggle.onValueChanged.RemoveListener(SetFullscreen);
    }

    private void SetMaster(float v) { AudioManager.Instance.SetMasterVolume(v); PlayerPrefs.SetFloat(MasterKey, v); }
    private void SetMusic(float v) { AudioManager.Instance.SetMusicVolume(v); PlayerPrefs.SetFloat(MusicKey, v); }
    private void SetSfx(float v) { AudioManager.Instance.SetSfxVolume(v); PlayerPrefs.SetFloat(SfxKey, v); }

    private void SetFullscreen(bool on)
    {
        Screen.fullScreen = on;
        PlayerPrefs.SetInt(FullscreenKey, on ? 1 : 0);
    }
}
