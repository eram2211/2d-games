using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Wire these methods to buttons on the Main Menu canvas: New Game, Continue, Settings, Quit.
/// </summary>
public class MainMenuController : MonoBehaviour
{
    [SerializeField] private GameObject settingsPanel;
    [SerializeField] private GameObject continueButton;
    [SerializeField] private SaveLoadManager saveLoad;

    private void Start()
    {
        if (continueButton != null)
            continueButton.SetActive(saveLoad != null && saveLoad.HasSave());
    }

    public void OnNewGame() => GameManager.Instance.StartNewGame();
    public void OnContinue() => GameManager.Instance.ContinueGame();
    public void OnOpenSettings() => settingsPanel.SetActive(true);
    public void OnCloseSettings() => settingsPanel.SetActive(false);

    public void OnQuit()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
