using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>Single inventory slot: icon + stack count. Attach to the slot prefab.</summary>
public class InventorySlotUI : MonoBehaviour
{
    [SerializeField] private Image icon;
    [SerializeField] private TMP_Text countText;

    public void Set(Sprite sprite, int count)
    {
        icon.sprite = sprite;
        icon.enabled = sprite != null;
        countText.text = count > 1 ? $"x{count}" : "";
    }
}
