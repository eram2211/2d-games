using UnityEngine;
using UnityEngine.Rendering.Universal;

/// <summary>
/// Smoothly transitions the URP 2D Global Light's color/intensity when entering
/// a new dream world, giving each world a distinct emotional lighting mood
/// (e.g. dim blue-grey for Fear, warm gold for Joy, pale desaturated for Sadness,
/// deep red for Anger, soft white for Hope).
/// </summary>
public class DynamicLight2DController : MonoBehaviour
{
    [SerializeField] private Light2D globalLight;
    [SerializeField] private float transitionSpeed = 1.5f;

    private Color _targetColor = Color.white;
    private float _targetIntensity = 1f;

    public void SetAmbient(Color color, float intensity)
    {
        _targetColor = color;
        _targetIntensity = intensity;
    }

    private void Update()
    {
        if (globalLight == null) return;
        globalLight.color = Color.Lerp(globalLight.color, _targetColor, Time.deltaTime * transitionSpeed);
        globalLight.intensity = Mathf.Lerp(globalLight.intensity, _targetIntensity, Time.deltaTime * transitionSpeed);
    }
}
