using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Overall flow controller: MainMenu -> Playing -> Paused -> GameOver -> Ending.
/// Uses the StateMachine class so flow logic doesn't turn into a spaghetti of bools.
/// This is the top-level singleton other managers can safely query.
/// </summary>
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    public enum Flow { MainMenu, Playing, Paused, GameOver, Ending }
    public Flow CurrentFlow { get; private set; } = Flow.MainMenu;

    [Header("References")]
    public InventorySystem Inventory;
    public SaveLoadManager SaveLoad;
    public CheckpointManager Checkpoints;
    public DreamWorldManager DreamWorlds;

    [Header("Progress")]
    public int TotalFragments = 25;
    public int FragmentsCollected { get; private set; }

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void OnEnable()
    {
        GameEvents.OnFragmentCollected += HandleFragmentCollected;
        GameEvents.OnPlayerDied += HandlePlayerDied;
        GameEvents.OnBossDefeated += HandleBossDefeated;
    }

    private void OnDisable()
    {
        GameEvents.OnFragmentCollected -= HandleFragmentCollected;
        GameEvents.OnPlayerDied -= HandlePlayerDied;
        GameEvents.OnBossDefeated -= HandleBossDefeated;
    }

    public void StartNewGame()
    {
        FragmentsCollected = 0;
        Inventory.Clear();
        CurrentFlow = Flow.Playing;
        SceneManager.LoadScene("Dream_Fear");
    }

    public void ContinueGame()
    {
        if (SaveLoad.HasSave())
        {
            SaveLoad.Load();
            CurrentFlow = Flow.Playing;
        }
        else
        {
            StartNewGame();
        }
    }

    public void TogglePause()
    {
        bool pausing = CurrentFlow == Flow.Playing;
        CurrentFlow = pausing ? Flow.Paused : Flow.Playing;
        Time.timeScale = pausing ? 0f : 1f;
        GameEvents.RaiseGamePaused(pausing);
    }

    public void ReturnToMainMenu()
    {
        Time.timeScale = 1f;
        CurrentFlow = Flow.MainMenu;
        SceneManager.LoadScene("MainMenu");
    }

    private void HandleFragmentCollected(MemoryFragmentData data)
    {
        if (Inventory.HasFragment(data.fragmentId)) return; // guard against double-count on reload
        Inventory.MarkFragmentCollected(data.fragmentId);
        FragmentsCollected++;
        GameEvents.RaiseFragmentCountChanged(FragmentsCollected, TotalFragments);
    }

    private void HandlePlayerDied()
    {
        CurrentFlow = Flow.GameOver;
    }

    private void HandleBossDefeated()
    {
        // Determine which ending the player earns based on choices made throughout the run.
        EndingType ending = EndingManager.Instance.EvaluateEnding(FragmentsCollected, TotalFragments, Inventory);
        CurrentFlow = Flow.Ending;
        GameEvents.RaiseEndingTriggered(ending);
    }
}
