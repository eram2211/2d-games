using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Generic component object pool. Used for particles, projectiles, enemy hit-fx, footstep dust, etc.
/// Avoids Instantiate/Destroy spikes which matter a lot in a pixel-art platformer with lots of particles.
/// </summary>
public class ObjectPool : MonoBehaviour
{
    [System.Serializable]
    public class Pool
    {
        public string id;
        public GameObject prefab;
        public int prewarmCount = 10;
    }

    [SerializeField] private List<Pool> _pools = new List<Pool>();
    private readonly Dictionary<string, Queue<GameObject>> _queues = new Dictionary<string, Queue<GameObject>>();
    private readonly Dictionary<string, GameObject> _prefabsById = new Dictionary<string, GameObject>();

    public static ObjectPool Instance { get; private set; }

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;

        foreach (var pool in _pools)
        {
            var queue = new Queue<GameObject>();
            _prefabsById[pool.id] = pool.prefab;
            for (int i = 0; i < pool.prewarmCount; i++)
                queue.Enqueue(CreateInstance(pool.prefab));
            _queues[pool.id] = queue;
        }
    }

    private GameObject CreateInstance(GameObject prefab)
    {
        var go = Instantiate(prefab, transform);
        go.SetActive(false);
        return go;
    }

    public GameObject Spawn(string id, Vector3 position, Quaternion rotation)
    {
        if (!_queues.TryGetValue(id, out var queue))
        {
            Debug.LogWarning($"No pool registered for id '{id}'.");
            return null;
        }

        GameObject go = queue.Count > 0 ? queue.Dequeue() : CreateInstance(_prefabsById[id]);
        go.transform.SetPositionAndRotation(position, rotation);
        go.SetActive(true);
        return go;
    }

    public void Despawn(string id, GameObject instance)
    {
        instance.SetActive(false);
        if (!_queues.ContainsKey(id)) _queues[id] = new Queue<GameObject>();
        _queues[id].Enqueue(instance);
    }
}
