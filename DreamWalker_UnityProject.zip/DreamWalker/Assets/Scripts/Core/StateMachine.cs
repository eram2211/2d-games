using System;
using System.Collections.Generic;

/// <summary>
/// Minimal, reusable finite state machine. Any gameplay actor (player, enemy, boss, GameManager)
/// composes one of these instead of re-implementing state logic every time.
/// </summary>
public class StateMachine
{
    public IState CurrentState { get; private set; }
    private readonly Dictionary<Type, IState> _states = new Dictionary<Type, IState>();

    public void RegisterState(IState state)
    {
        _states[state.GetType()] = state;
    }

    public void ChangeState<T>() where T : IState
    {
        if (!_states.TryGetValue(typeof(T), out var next))
        {
            UnityEngine.Debug.LogError($"State {typeof(T)} not registered.");
            return;
        }
        ChangeState(next);
    }

    public void ChangeState(IState next)
    {
        if (CurrentState == next) return;
        CurrentState?.Exit();
        CurrentState = next;
        CurrentState.Enter();
    }

    public void Tick() => CurrentState?.Tick();
    public void FixedTick() => CurrentState?.FixedTick();
}
