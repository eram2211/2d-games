using System;
using UnityEngine;

/// <summary>
/// Central event bus for the whole game (Observer pattern).
/// Systems subscribe/unsubscribe instead of holding direct references to each other,
/// keeping the architecture decoupled and modular.
/// </summary>
public static class GameEvents
{
    // ---- Player events ----
    public static event Action<float, float> OnPlayerHealthChanged; // current, max
    public static event Action OnPlayerDied;
    public static event Action<Vector2> OnPlayerRespawn;

    // ---- World events ----
    public static event Action<DreamWorldType> OnDreamWorldEntered;
    public static event Action<MemoryFragmentData> OnFragmentCollected;
    public static event Action<int, int> OnFragmentCountChanged; // collected, total

    // ---- Checkpoint / Save ----
    public static event Action<Checkpoint> OnCheckpointReached;
    public static event Action OnGameSaved;
    public static event Action OnGameLoaded;

    // ---- Dialogue ----
    public static event Action<DialogueSO> OnDialogueStarted;
    public static event Action OnDialogueEnded;

    // ---- Boss / Ending ----
    public static event Action OnBossDefeated;
    public static event Action<EndingType> OnEndingTriggered;

    // ---- UI ----
    public static event Action<bool> OnGamePaused;

    public static void RaisePlayerHealthChanged(float cur, float max) => OnPlayerHealthChanged?.Invoke(cur, max);
    public static void RaisePlayerDied() => OnPlayerDied?.Invoke();
    public static void RaisePlayerRespawn(Vector2 pos) => OnPlayerRespawn?.Invoke(pos);

    public static void RaiseDreamWorldEntered(DreamWorldType type) => OnDreamWorldEntered?.Invoke(type);
    public static void RaiseFragmentCollected(MemoryFragmentData data) => OnFragmentCollected?.Invoke(data);
    public static void RaiseFragmentCountChanged(int collected, int total) => OnFragmentCountChanged?.Invoke(collected, total);

    public static void RaiseCheckpointReached(Checkpoint cp) => OnCheckpointReached?.Invoke(cp);
    public static void RaiseGameSaved() => OnGameSaved?.Invoke();
    public static void RaiseGameLoaded() => OnGameLoaded?.Invoke();

    public static void RaiseDialogueStarted(DialogueSO d) => OnDialogueStarted?.Invoke(d);
    public static void RaiseDialogueEnded() => OnDialogueEnded?.Invoke();

    public static void RaiseBossDefeated() => OnBossDefeated?.Invoke();
    public static void RaiseEndingTriggered(EndingType type) => OnEndingTriggered?.Invoke(type);

    public static void RaiseGamePaused(bool paused) => OnGamePaused?.Invoke(paused);
}
