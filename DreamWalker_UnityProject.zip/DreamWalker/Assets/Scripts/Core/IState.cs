/// <summary>
/// Generic interface for any state used by a StateMachine (player, enemy, boss, game flow...).
/// </summary>
public interface IState
{
    void Enter();
    void Tick();      // called every frame (Update)
    void FixedTick();  // called every physics frame (FixedUpdate)
    void Exit();
}
