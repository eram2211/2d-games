using UnityEngine;

/// <summary>
/// Platform in the Hope world that's invisible until the player gets close,
/// then fades in (both visually and for its collider) to reward exploration.
/// </summary>
public class HiddenPlatform : MonoBehaviour
{
    [SerializeField] private float revealRadius = 3f;
    [SerializeField] private float fadeSpeed = 3f;
    [SerializeField] private SpriteRenderer sr;
    [SerializeField] private Collider2D col;

    private Transform _player;
    private float _targetAlpha = 0f;

    private void Awake()
    {
        _player = GameObject.FindGameObjectWithTag("Player")?.transform;
        SetAlpha(0f);
        if (col != null) col.enabled = false;
    }

    private void Update()
    {
        if (_player == null) return;

        bool near = Vector2.Distance(transform.position, _player.position) <= revealRadius;
        _targetAlpha = near ? 1f : 0f;
        if (col != null) col.enabled = near;

        float newAlpha = Mathf.MoveTowards(sr.color.a, _targetAlpha, fadeSpeed * Time.deltaTime);
        SetAlpha(newAlpha);
    }

    private void SetAlpha(float a)
    {
        var c = sr.color;
        c.a = a;
        sr.color = c;
    }
}
