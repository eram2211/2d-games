using UnityEngine;

/// <summary>
/// Wall exclusive to the Anger world that can be destroyed by the player attacking it
/// (e.g. a punch/smash action bound in PlayerController, or contact from a rolling hazard).
/// </summary>
public class BreakableWall : MonoBehaviour
{
    [SerializeField] private int hitsToBreak = 3;
    [SerializeField] private string breakVfxPoolId = "WallDebris";
    private int _hits;

    public void Hit()
    {
        _hits++;
        AudioManager.Instance?.PlaySfx("wall_crack");

        if (_hits >= hitsToBreak)
            Break();
    }

    private void Break()
    {
        ObjectPool.Instance?.Spawn(breakVfxPoolId, transform.position, Quaternion.identity);
        AudioManager.Instance?.PlaySfx("wall_break");
        gameObject.SetActive(false);
    }
}
