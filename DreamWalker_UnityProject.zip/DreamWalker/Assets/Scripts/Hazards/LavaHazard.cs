using UnityEngine;

/// <summary>
/// Instant/periodic damage zone for the Anger world's lava. Deals damage on entry
/// and repeatedly while the player stays inside.
/// </summary>
[RequireComponent(typeof(Collider2D))]
public class LavaHazard : MonoBehaviour
{
    [SerializeField] private float damage = 20f;
    [SerializeField] private float tickInterval = 1f;
    private float _timer;

    private void Reset() => GetComponent<Collider2D>().isTrigger = true;

    private void OnTriggerStay2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;

        _timer -= Time.deltaTime;
        if (_timer <= 0f)
        {
            other.GetComponent<PlayerHealth>()?.TakeDamage(damage);
            _timer = tickInterval;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player")) _timer = 0f;
    }
}
