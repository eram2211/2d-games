using UnityEngine;

/// <summary>
/// Gently bobbing platform used in the Joy world. Purely visual/physical motion;
/// works with any collider resting on top since it's a real moving transform.
/// </summary>
public class FloatingPlatform : MonoBehaviour
{
    [SerializeField] private float floatHeight = 0.5f;
    [SerializeField] private float floatSpeed = 1.5f;
    private Vector3 _startPos;

    private void Awake() => _startPos = transform.position;

    private void Update()
    {
        float y = Mathf.Sin(Time.time * floatSpeed) * floatHeight;
        transform.position = _startPos + new Vector3(0, y, 0);
    }
}
