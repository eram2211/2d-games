/// <summary>The possible endings the player can earn.</summary>
public enum EndingType
{
    None,
    TrueAwakening,   // collected all fragments + made compassionate choices
    BittersweetWake, // collected most fragments
    LostInDreams,    // too few fragments / negative choices - "bad" ending
    AcceptanceEnding // special ending for balanced emotional choices (neutral/hope-leaning)
}
