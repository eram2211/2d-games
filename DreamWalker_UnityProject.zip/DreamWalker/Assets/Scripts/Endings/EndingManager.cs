using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Tracks dialogue-choice "influence" accumulated across the playthrough and combines it
/// with fragment-collection percentage to decide which of the multiple endings fires
/// after the boss battle. Keeping this centralized means ending logic isn't scattered
/// across dialogue trees.
/// </summary>
public class EndingManager : MonoBehaviour
{
    public static EndingManager Instance { get; private set; }

    private readonly Dictionary<EndingType, int> _influenceScores = new Dictionary<EndingType, int>();

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    public void RegisterInfluence(EndingType type)
    {
        if (type == EndingType.None) return;
        if (!_influenceScores.ContainsKey(type)) _influenceScores[type] = 0;
        _influenceScores[type]++;
    }

    public EndingType EvaluateEnding(int fragmentsCollected, int totalFragments, InventorySystem inventory)
    {
        float pct = totalFragments > 0 ? (float)fragmentsCollected / totalFragments : 0f;

        // Fragment completion is the primary gate; dialogue influence breaks ties/nuances.
        if (pct >= 0.9f)
            return EndingType.TrueAwakening;

        if (pct >= 0.5f)
            return HighestInfluenceOr(EndingType.BittersweetWake);

        if (pct < 0.25f)
            return EndingType.LostInDreams;

        return HighestInfluenceOr(EndingType.AcceptanceEnding);
    }

    private EndingType HighestInfluenceOr(EndingType fallback)
    {
        EndingType best = fallback;
        int bestScore = -1;
        foreach (var kv in _influenceScores)
        {
            if (kv.Value > bestScore) { bestScore = kv.Value; best = kv.Key; }
        }
        return best;
    }
}
