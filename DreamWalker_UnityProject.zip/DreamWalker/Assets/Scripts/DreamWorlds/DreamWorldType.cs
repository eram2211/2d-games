/// <summary>The five emotional dream worlds.</summary>
public enum DreamWorldType
{
    Fear,
    Joy,
    Sadness,
    Anger,
    Hope
}
