using UnityEngine;
using UnityEngine.Rendering.Universal;

/// <summary>
/// Drives the "limited visibility" mechanic for the Fear world by shrinking a
/// 2D Light (Point Light, radial falloff) around the player, effectively creating
/// a fog-of-war vision cone. Requires URP's 2D Renderer with a Light2D component.
/// </summary>
public class VisibilityController : MonoBehaviour
{
    [SerializeField] private Light2D _playerLight;
    [SerializeField] private float _defaultRadius = 100f; // effectively "unlimited" for other worlds
    [SerializeField] private float _transitionSpeed = 2f;

    private float _targetRadius;
    private bool _active;

    private void Awake()
    {
        _targetRadius = _defaultRadius;
    }

    public void SetActive(bool active, float visionRadius)
    {
        _active = active;
        _targetRadius = active ? visionRadius : _defaultRadius;

        if (_playerLight != null)
            _playerLight.pointLightOuterRadius = active ? _playerLight.pointLightOuterRadius : _defaultRadius;
    }

    private void Update()
    {
        if (_playerLight == null) return;
        _playerLight.pointLightOuterRadius = Mathf.Lerp(
            _playerLight.pointLightOuterRadius, _targetRadius, Time.deltaTime * _transitionSpeed);
    }
}
