using UnityEngine;

/// <summary>
/// ScriptableObject that defines how a dream world modifies gameplay.
/// Designers can tune each world entirely from the Inspector with no code changes,
/// and new worlds can be added by just creating a new asset.
/// Create via: Assets > Create > DreamWalker > Dream World Config
/// </summary>
[CreateAssetMenu(fileName = "NewDreamWorld", menuName = "DreamWalker/Dream World Config")]
public class DreamWorldSO : ScriptableObject
{
    public DreamWorldType worldType;
    public string displayName;
    [TextArea] public string description;
    public Sprite worldIcon;

    [Header("Movement Modifiers")]
    [Tooltip("Multiplier applied to player horizontal move speed.")]
    public float moveSpeedMultiplier = 1f;
    [Tooltip("Multiplier applied to player jump force.")]
    public float jumpForceMultiplier = 1f;
    [Tooltip("Multiplier applied to gravity scale (lower = floatier).")]
    public float gravityMultiplier = 1f;

    [Header("Visibility (Fear world)")]
    public bool useLimitedVisibility = false;
    [Range(1f, 15f)] public float visionRadius = 5f;

    [Header("Weather")]
    public bool hasRain = false;
    public bool hasFloatingParticles = false;

    [Header("Lighting")]
    public Color ambientLightColor = Color.white;
    [Range(0f, 1f)] public float ambientIntensity = 1f;

    [Header("Hazards / Mechanics")]
    public bool spawnsEnemies = false;
    public bool wallsBreakable = false;
    public bool hasLava = false;
    public bool hasHiddenPlatforms = false;
    public bool hasFloatingPlatforms = false;

    [Header("Audio")]
    public AudioClip ambientTrack;
    public AudioClip musicTrack;
}
