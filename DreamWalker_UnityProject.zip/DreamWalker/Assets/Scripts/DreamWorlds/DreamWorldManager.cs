using UnityEngine;

/// <summary>
/// Applies the active DreamWorldSO's rules to the player, camera, lighting and weather
/// whenever a new dream-world scene loads. This is the single place gameplay-per-world
/// logic is wired together, keeping PlayerController itself world-agnostic.
/// </summary>
public class DreamWorldManager : MonoBehaviour
{
    [SerializeField] private DreamWorldSO _activeWorld;
    [SerializeField] private PlayerController _player;
    [SerializeField] private WeatherController _weather;
    [SerializeField] private DynamicLight2DController _lighting;
    [SerializeField] private VisibilityController _visibility;
    [SerializeField] private AudioManager _audio;

    public DreamWorldSO ActiveWorld => _activeWorld;

    private void Start()
    {
        ApplyWorld(_activeWorld);
    }

    public void ApplyWorld(DreamWorldSO world)
    {
        if (world == null) return;
        _activeWorld = world;

        // Movement rules
        _player?.ApplyWorldModifiers(world.moveSpeedMultiplier, world.jumpForceMultiplier, world.gravityMultiplier);

        // Visibility (Fear)
        if (_visibility != null)
            _visibility.SetActive(world.useLimitedVisibility, world.visionRadius);

        // Weather (Sadness rain / Hope particles)
        _weather?.Configure(world.hasRain, world.hasFloatingParticles);

        // Lighting
        _lighting?.SetAmbient(world.ambientLightColor, world.ambientIntensity);

        // Audio
        if (_audio != null)
        {
            _audio.PlayMusic(world.musicTrack);
            _audio.PlayAmbient(world.ambientTrack);
        }

        GameEvents.RaiseDreamWorldEntered(world.worldType);
        Debug.Log($"[DreamWorldManager] Entered world: {world.displayName}");
    }
}
