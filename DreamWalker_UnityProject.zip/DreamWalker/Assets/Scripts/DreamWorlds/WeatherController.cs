using UnityEngine;

/// <summary>
/// Toggles weather-related particle systems per dream world (rain in Sadness,
/// drifting light particles in Hope/Joy). Uses simple enable/disable rather than
/// destroying systems so transitions are instant and cheap.
/// </summary>
public class WeatherController : MonoBehaviour
{
    [SerializeField] private ParticleSystem _rainParticles;
    [SerializeField] private ParticleSystem _floatingParticles; // fireflies / light motes for Hope, petals for Joy
    [SerializeField] private AudioSource _rainAudioSource;

    public void Configure(bool rain, bool floatingParticles)
    {
        SetSystem(_rainParticles, rain);
        SetSystem(_floatingParticles, floatingParticles);

        if (_rainAudioSource != null)
        {
            if (rain && !_rainAudioSource.isPlaying) _rainAudioSource.Play();
            if (!rain && _rainAudioSource.isPlaying) _rainAudioSource.Stop();
        }
    }

    private void SetSystem(ParticleSystem ps, bool active)
    {
        if (ps == null) return;
        if (active && !ps.isPlaying) ps.Play();
        if (!active && ps.isPlaying) ps.Stop();
    }
}
