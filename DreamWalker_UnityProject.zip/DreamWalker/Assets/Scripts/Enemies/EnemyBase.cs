using UnityEngine;

/// <summary>
/// Shared enemy functionality: health, damage-on-touch, death VFX via pooling.
/// Concrete enemies (FearMonster, boss phases) extend this for movement/attack behaviour.
/// </summary>
public abstract class EnemyBase : MonoBehaviour
{
    [SerializeField] protected float maxHealth = 30f;
    [SerializeField] protected float contactDamage = 10f;
    [SerializeField] protected string deathVfxPoolId = "EnemyDeathPoof";

    protected float currentHealth;

    protected virtual void Awake()
    {
        currentHealth = maxHealth;
    }

    public virtual void TakeDamage(float amount)
    {
        currentHealth -= amount;
        AudioManager.Instance?.PlaySfx("enemy_hit");
        if (currentHealth <= 0f) Die();
    }

    protected virtual void Die()
    {
        ObjectPool.Instance?.Spawn(deathVfxPoolId, transform.position, Quaternion.identity);
        AudioManager.Instance?.PlaySfx("enemy_death");
        gameObject.SetActive(false);
    }

    protected virtual void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Player"))
        {
            collision.collider.GetComponent<PlayerHealth>()?.TakeDamage(contactDamage);
        }
    }
}
