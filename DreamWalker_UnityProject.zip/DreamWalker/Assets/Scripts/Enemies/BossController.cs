using UnityEngine;

/// <summary>
/// The final boss ("The Nightmare" - a manifestation of all five emotions combined).
/// Uses its own StateMachine for attack phases. Triggers GameEvents.OnBossDefeated
/// on death, which GameManager listens to in order to resolve the ending.
/// </summary>
public class BossController : MonoBehaviour
{
    [Header("Stats")]
    public float maxHealth = 300f;
    public float phaseTwoThreshold = 0.5f; // switch to aggressive phase below 50% hp

    public StateMachine StateMachine { get; private set; }
    public Rigidbody2D Body { get; private set; }
    public Transform Player { get; private set; }

    private float _currentHealth;

    private void Awake()
    {
        Body = GetComponent<Rigidbody2D>();
        Player = GameObject.FindGameObjectWithTag("Player")?.transform;
        _currentHealth = maxHealth;

        StateMachine = new StateMachine();
        StateMachine.RegisterState(new BossPhaseOneState(this));
        StateMachine.RegisterState(new BossPhaseTwoState(this));
        StateMachine.RegisterState(new BossDefeatedState(this));
    }

    private void Start() => StateMachine.ChangeState<BossPhaseOneState>();

    private void Update() => StateMachine.Tick();
    private void FixedUpdate() => StateMachine.FixedTick();

    public void TakeDamage(float amount)
    {
        if (StateMachine.CurrentState is BossDefeatedState) return;

        _currentHealth -= amount;
        AudioManager.Instance?.PlaySfx("boss_hit");

        if (_currentHealth <= 0f)
        {
            StateMachine.ChangeState<BossDefeatedState>();
        }
        else if (_currentHealth / maxHealth <= phaseTwoThreshold &&
                 !(StateMachine.CurrentState is BossPhaseTwoState))
        {
            StateMachine.ChangeState<BossPhaseTwoState>();
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Player"))
            collision.collider.GetComponent<PlayerHealth>()?.TakeDamage(15f);
    }
}

/// <summary>Slow telegraphed attacks, boss moves toward player at moderate speed.</summary>
public class BossPhaseOneState : IState
{
    private readonly BossController boss;
    private float _attackTimer;
    public BossPhaseOneState(BossController boss) { this.boss = boss; }

    public void Enter() { _attackTimer = 2f; boss.GetComponent<Animator>()?.Play("Boss_Phase1_Idle"); }
    public void Tick()
    {
        _attackTimer -= Time.deltaTime;
        if (_attackTimer <= 0f)
        {
            _attackTimer = 2f;
            boss.GetComponent<Animator>()?.Play("Boss_Phase1_Attack");
            AudioManager.Instance?.PlaySfx("boss_attack");
        }
    }
    public void FixedTick()
    {
        if (boss.Player == null) return;
        Vector2 dir = ((Vector2)boss.Player.position - boss.Body.position).normalized;
        boss.Body.linearVelocity = new Vector2(dir.x * 1.5f, boss.Body.linearVelocity.y);
    }
    public void Exit() { }
}

/// <summary>Faster, more frequent attacks once below the HP threshold.</summary>
public class BossPhaseTwoState : IState
{
    private readonly BossController boss;
    private float _attackTimer;
    public BossPhaseTwoState(BossController boss) { this.boss = boss; }

    public void Enter()
    {
        _attackTimer = 1f;
        boss.GetComponent<Animator>()?.Play("Boss_Phase2_Idle");
        AudioManager.Instance?.PlaySfx("boss_enrage");
    }
    public void Tick()
    {
        _attackTimer -= Time.deltaTime;
        if (_attackTimer <= 0f)
        {
            _attackTimer = 1f;
            boss.GetComponent<Animator>()?.Play("Boss_Phase2_Attack");
            AudioManager.Instance?.PlaySfx("boss_attack");
        }
    }
    public void FixedTick()
    {
        if (boss.Player == null) return;
        Vector2 dir = ((Vector2)boss.Player.position - boss.Body.position).normalized;
        boss.Body.linearVelocity = new Vector2(dir.x * 3f, boss.Body.linearVelocity.y);
    }
    public void Exit() { }
}

public class BossDefeatedState : IState
{
    private readonly BossController boss;
    public BossDefeatedState(BossController boss) { this.boss = boss; }

    public void Enter()
    {
        boss.Body.linearVelocity = Vector2.zero;
        boss.GetComponent<Animator>()?.Play("Boss_Defeated");
        AudioManager.Instance?.PlaySfx("boss_defeated");
        GameEvents.RaiseBossDefeated();
    }
    public void Tick() { }
    public void FixedTick() { }
    public void Exit() { }
}
