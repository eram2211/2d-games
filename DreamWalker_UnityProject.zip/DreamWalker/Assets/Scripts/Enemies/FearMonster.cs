using UnityEngine;

/// <summary>
/// Simple patrol-and-chase enemy exclusive to the Fear dream world. Patrols between
/// two points; when the player enters its detection radius it chases them.
/// </summary>
public class FearMonster : EnemyBase
{
    [SerializeField] private Transform pointA;
    [SerializeField] private Transform pointB;
    [SerializeField] private float moveSpeed = 2.5f;
    [SerializeField] private float chaseSpeed = 4f;
    [SerializeField] private float detectionRadius = 4f;

    private Transform _target;
    private Transform _player;
    private Rigidbody2D _body;

    protected override void Awake()
    {
        base.Awake();
        _body = GetComponent<Rigidbody2D>();
        _target = pointB;
        _player = GameObject.FindGameObjectWithTag("Player")?.transform;
    }

    private void Update()
    {
        bool chasing = _player != null && Vector2.Distance(transform.position, _player.position) <= detectionRadius;
        Transform destination = chasing ? _player : _target;
        float speed = chasing ? chaseSpeed : moveSpeed;

        Vector2 dir = ((Vector2)destination.position - _body.position).normalized;
        _body.linearVelocity = new Vector2(dir.x * speed, _body.linearVelocity.y);

        if (dir.x != 0)
            transform.localScale = new Vector3(Mathf.Sign(dir.x), 1, 1);

        if (!chasing && Vector2.Distance(transform.position, _target.position) < 0.2f)
            _target = _target == pointA ? pointB : pointA;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);
    }
}
