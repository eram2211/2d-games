using UnityEngine;

/// <summary>
/// Smooth-damped 2D camera follow with optional level bounds clamping and a
/// look-ahead offset in the direction of player movement. No Cinemachine dependency
/// so it works in any Unity 2D project out of the box.
/// </summary>
public class SmoothCameraFollow : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private float smoothTime = 0.2f;
    [SerializeField] private Vector2 lookAheadFactor = new Vector2(0.5f, 0f);
    [SerializeField] private float lookAheadSmoothTime = 0.5f;

    [Header("Bounds (optional)")]
    [SerializeField] private bool useBounds = false;
    [SerializeField] private Vector2 minBounds;
    [SerializeField] private Vector2 maxBounds;

    private Vector3 _velocity;
    private Vector2 _lookAheadPos;
    private Vector2 _lastTargetPos;

    private void LateUpdate()
    {
        if (target == null) return;

        Vector2 targetVelocity = ((Vector2)target.position - _lastTargetPos) / Mathf.Max(Time.deltaTime, 0.0001f);
        _lastTargetPos = target.position;

        _lookAheadPos = Vector2.Lerp(_lookAheadPos,
            new Vector2(targetVelocity.x * lookAheadFactor.x, targetVelocity.y * lookAheadFactor.y),
            Time.deltaTime / lookAheadSmoothTime);

        Vector3 desired = new Vector3(
            target.position.x + _lookAheadPos.x,
            target.position.y + _lookAheadPos.y,
            transform.position.z);

        if (useBounds)
        {
            desired.x = Mathf.Clamp(desired.x, minBounds.x, maxBounds.x);
            desired.y = Mathf.Clamp(desired.y, minBounds.y, maxBounds.y);
        }

        transform.position = Vector3.SmoothDamp(transform.position, desired, ref _velocity, smoothTime);
    }

    public void SetTarget(Transform newTarget) => target = newTarget;
}
