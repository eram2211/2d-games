using UnityEngine;

/// <summary>
/// Plays footstep SFX at an interval while the player is grounded and moving.
/// Interval can be slowed down for the Sadness world to match reduced move speed.
/// </summary>
public class FootstepController : MonoBehaviour
{
    [SerializeField] private float baseInterval = 0.35f;
    [SerializeField] private string sfxId = "footstep";
    private float _timer;
    private float _intervalMultiplier = 1f;

    public void SetIntervalMultiplier(float mult) => _intervalMultiplier = mult;

    public void NotifyMoving(bool grounded)
    {
        if (!grounded) return;

        _timer -= Time.deltaTime;
        if (_timer <= 0f)
        {
            AudioManager.Instance?.PlaySfx(sfxId);
            _timer = baseInterval * _intervalMultiplier;
        }
    }

    public void NotifyIdle() => _timer = 0f;
}
