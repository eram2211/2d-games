using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

/// <summary>
/// Central audio hub: music (crossfaded per dream world), ambient loops, and pooled
/// one-shot SFX (UI, footsteps, combat). Volumes route through an AudioMixer so the
/// Settings menu can control Master/Music/SFX independently.
/// </summary>
public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance { get; private set; }

    [Header("Mixer")]
    public AudioMixer mixer;

    [Header("Sources")]
    [SerializeField] private AudioSource musicSourceA;
    [SerializeField] private AudioSource musicSourceB;
    [SerializeField] private AudioSource ambientSource;
    [SerializeField] private AudioSource sfxSource; // for one-shot SFX

    [Header("SFX Library")]
    [SerializeField] private List<NamedClip> sfxClips = new List<NamedClip>();

    [Serializable]
    public class NamedClip { public string id; public AudioClip clip; }

    private Dictionary<string, AudioClip> _sfxLookup;
    private bool _usingSourceA = true;
    private float _crossfadeSpeed = 1.5f;
    private AudioClip _pendingMusic;
    private float _fadeT;
    private bool _fading;

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        _sfxLookup = new Dictionary<string, AudioClip>();
        foreach (var nc in sfxClips) _sfxLookup[nc.id] = nc.clip;
    }

    private void Update()
    {
        if (!_fading) return;

        _fadeT += Time.unscaledDeltaTime * _crossfadeSpeed;
        AudioSource from = _usingSourceA ? musicSourceA : musicSourceB;
        AudioSource to = _usingSourceA ? musicSourceB : musicSourceA;

        from.volume = Mathf.Lerp(1f, 0f, _fadeT);
        to.volume = Mathf.Lerp(0f, 1f, _fadeT);

        if (_fadeT >= 1f)
        {
            from.Stop();
            _fading = false;
            _usingSourceA = !_usingSourceA;
        }
    }

    public void PlayMusic(AudioClip clip)
    {
        if (clip == null) return;
        AudioSource to = _usingSourceA ? musicSourceB : musicSourceA;
        if (to.clip == clip) return;

        to.clip = clip;
        to.volume = 0f;
        to.loop = true;
        to.Play();

        _fadeT = 0f;
        _fading = true;
    }

    public void PlayAmbient(AudioClip clip)
    {
        if (clip == null || ambientSource.clip == clip) return;
        ambientSource.clip = clip;
        ambientSource.loop = true;
        ambientSource.Play();
    }

    public void PlaySfx(string id)
    {
        if (_sfxLookup.TryGetValue(id, out var clip) && clip != null)
            sfxSource.PlayOneShot(clip);
    }

    public void PlaySfxOneShot(AudioClip clip)
    {
        if (clip != null) sfxSource.PlayOneShot(clip);
    }

    // ---- Settings menu hooks (values in dB via logarithmic slider conversion) ----
    public void SetMasterVolume(float linear01) => mixer.SetFloat("MasterVolume", LinearToDb(linear01));
    public void SetMusicVolume(float linear01) => mixer.SetFloat("MusicVolume", LinearToDb(linear01));
    public void SetSfxVolume(float linear01) => mixer.SetFloat("SFXVolume", LinearToDb(linear01));

    private float LinearToDb(float linear01) => Mathf.Log10(Mathf.Clamp(linear01, 0.0001f, 1f)) * 20f;
}
