using UnityEngine;

/// <summary>
/// A branching-capable dialogue tree stored as a ScriptableObject so writers can author
/// conversations without touching code. Create via Assets > Create > DreamWalker > Dialogue.
/// </summary>
[CreateAssetMenu(fileName = "NewDialogue", menuName = "DreamWalker/Dialogue")]
public class DialogueSO : ScriptableObject
{
    [System.Serializable]
    public class Choice
    {
        public string choiceText;
        [Tooltip("Index of the DialogueLine to jump to, or -1 to end the conversation.")]
        public int nextLineIndex = -1;
        [Tooltip("Optional: this choice affects which ending the player earns.")]
        public EndingType endingInfluence = EndingType.None;
    }

    [System.Serializable]
    public class DialogueLine
    {
        public string speakerName;
        [TextArea(2, 5)] public string text;
        public AudioClip voiceBlip;
        public Choice[] choices; // empty = auto-advance to next line in array order
    }

    public string npcId;
    public DialogueLine[] lines;
}
