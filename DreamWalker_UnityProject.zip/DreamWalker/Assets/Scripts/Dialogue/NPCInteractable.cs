using UnityEngine;

/// <summary>
/// Put on any NPC. Shows a prompt when the player is nearby and starts the assigned
/// dialogue when the player presses the interact button.
/// </summary>
public class NPCInteractable : MonoBehaviour
{
    [SerializeField] private DialogueSO _dialogue;
    [SerializeField] private GameObject _interactPrompt; // e.g. a small "Press E" bubble
    [SerializeField] private KeyCode _interactKey = KeyCode.E;

    private bool _playerInRange;

    private void Update()
    {
        if (_playerInRange && Input.GetKeyDown(_interactKey) && !DialogueManager.Instance.IsActive)
        {
            DialogueManager.Instance.StartDialogue(_dialogue);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;
        _playerInRange = true;
        if (_interactPrompt) _interactPrompt.SetActive(true);
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;
        _playerInRange = false;
        if (_interactPrompt) _interactPrompt.SetActive(false);
    }
}
