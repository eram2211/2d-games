using UnityEngine;

/// <summary>
/// Runs a DialogueSO conversation: shows lines, handles player choice selection,
/// pauses gameplay input while active. UI rendering is delegated to DialogueUI.
/// </summary>
public class DialogueManager : MonoBehaviour
{
    public static DialogueManager Instance { get; private set; }

    [SerializeField] private DialogueUI _ui;

    private DialogueSO _current;
    private int _lineIndex;
    public bool IsActive { get; private set; }

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    public void StartDialogue(DialogueSO dialogue)
    {
        if (dialogue == null || dialogue.lines.Length == 0) return;

        _current = dialogue;
        _lineIndex = 0;
        IsActive = true;
        Time.timeScale = 0f; // freeze gameplay during conversation

        GameEvents.RaiseDialogueStarted(dialogue);
        ShowCurrentLine();
    }

    private void ShowCurrentLine()
    {
        var line = _current.lines[_lineIndex];
        _ui.DisplayLine(line, OnChoiceSelected, AdvanceAuto);
        if (line.voiceBlip != null) AudioManager.Instance?.PlaySfxOneShot(line.voiceBlip);
    }

    private void AdvanceAuto()
    {
        _lineIndex++;
        if (_lineIndex >= _current.lines.Length) { EndDialogue(); return; }
        ShowCurrentLine();
    }

    private void OnChoiceSelected(DialogueSO.Choice choice)
    {
        if (choice.endingInfluence != EndingType.None)
            EndingManager.Instance?.RegisterInfluence(choice.endingInfluence);

        if (choice.nextLineIndex < 0 || choice.nextLineIndex >= _current.lines.Length)
        {
            EndDialogue();
        }
        else
        {
            _lineIndex = choice.nextLineIndex;
            ShowCurrentLine();
        }
    }

    private void EndDialogue()
    {
        IsActive = false;
        Time.timeScale = 1f;
        _ui.Hide();
        GameEvents.RaiseDialogueEnded();
    }
}
