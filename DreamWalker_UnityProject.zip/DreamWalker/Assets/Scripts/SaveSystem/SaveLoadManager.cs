using System;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Handles writing/reading SaveData as JSON to Application.persistentDataPath.
/// Kept as a single responsibility class so the save format can change (e.g. to
/// binary or cloud save) without touching gameplay code.
/// </summary>
public class SaveLoadManager : MonoBehaviour
{
    private string SavePath => Path.Combine(Application.persistentDataPath, "dreamwalker_save.json");

    [SerializeField] private PlayerHealth _playerHealth;
    [SerializeField] private InventorySystem _inventory;
    [SerializeField] private CheckpointManager _checkpoints;

    public bool HasSave() => File.Exists(SavePath);

    public void Save()
    {
        var data = new SaveData
        {
            sceneName = SceneManager.GetActiveScene().name,
            playerPosX = _playerHealth.transform.position.x,
            playerPosY = _playerHealth.transform.position.y,
            currentHealth = _playerHealth.CurrentHealth,
            fragmentsCollected = GameManager.Instance.FragmentsCollected,
            collectedFragmentIds = new System.Collections.Generic.List<string>(_inventory.CollectedFragmentIds),
            inventoryItems = _inventory.ExportItems(),
            lastCheckpointId = _checkpoints.CurrentCheckpointId,
            saveTimestampUtc = DateTime.UtcNow.ToString("o")
        };

        try
        {
            string json = JsonUtility.ToJson(data, true);
            File.WriteAllText(SavePath, json);
            GameEvents.RaiseGameSaved();
            Debug.Log($"[SaveLoadManager] Saved to {SavePath}");
        }
        catch (Exception e)
        {
            Debug.LogError($"[SaveLoadManager] Save failed: {e.Message}");
        }
    }

    public void Load()
    {
        if (!HasSave()) return;

        try
        {
            string json = File.ReadAllText(SavePath);
            var data = JsonUtility.FromJson<SaveData>(json);

            if (SceneManager.GetActiveScene().name != data.sceneName)
            {
                SceneManager.LoadScene(data.sceneName);
            }

            _inventory.ImportState(data.inventoryItems, data.collectedFragmentIds);
            _playerHealth.RespawnAt(new Vector2(data.playerPosX, data.playerPosY));
            _checkpoints.SetCurrentCheckpoint(data.lastCheckpointId);

            GameEvents.RaiseGameLoaded();
            Debug.Log("[SaveLoadManager] Load complete.");
        }
        catch (Exception e)
        {
            Debug.LogError($"[SaveLoadManager] Load failed: {e.Message}");
        }
    }

    public void DeleteSave()
    {
        if (HasSave()) File.Delete(SavePath);
    }
}
