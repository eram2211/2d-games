using System;
using System.Collections.Generic;

/// <summary>
/// Plain serializable data container written to/read from disk as JSON.
/// Kept free of MonoBehaviour/UnityEngine object refs so JsonUtility can serialize it cleanly.
/// </summary>
[Serializable]
public class SaveData
{
    public string sceneName;
    public float playerPosX;
    public float playerPosY;
    public float currentHealth;
    public int fragmentsCollected;
    public List<string> collectedFragmentIds = new List<string>();
    public List<InventorySystem.InventoryEntry> inventoryItems = new List<InventorySystem.InventoryEntry>();
    public string lastCheckpointId;
    public string saveTimestampUtc;
}
