using UnityEngine;

/// <summary>
/// ScriptableObject describing a collectible/inventory item (keys, world-specific tools,
/// memory fragment types). Create via Assets > Create > DreamWalker > Item.
/// </summary>
[CreateAssetMenu(fileName = "NewItem", menuName = "DreamWalker/Item")]
public class ItemSO : ScriptableObject
{
    public string itemId;
    public string displayName;
    [TextArea] public string description;
    public Sprite icon;
    public bool stackable = true;
    public bool isKeyItem = false; // key items may gate doors / affect ending
}
