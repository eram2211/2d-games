using UnityEngine;

/// <summary>
/// Data describing one specific memory fragment collectible placed in the world,
/// including the emotional world it belongs to and an optional memory snippet
/// shown to the player when collected (feeds into the narrative/ending state).
/// </summary>
[CreateAssetMenu(fileName = "NewMemoryFragment", menuName = "DreamWalker/Memory Fragment")]
public class MemoryFragmentData : ScriptableObject
{
    public string fragmentId;
    public DreamWorldType belongsToWorld;
    [TextArea(3, 6)] public string memoryText;
    public Sprite icon;
}
