using UnityEngine;

/// <summary>
/// A pickable collectible placed in the level. On trigger, notifies GameEvents,
/// plays a pooled sparkle VFX + sound, then deactivates itself.
/// </summary>
[RequireComponent(typeof(Collider2D))]
public class MemoryFragment : MonoBehaviour
{
    [SerializeField] private MemoryFragmentData _data;
    [SerializeField] private string _pickupVfxPoolId = "FragmentSparkle";

    private void Reset()
    {
        GetComponent<Collider2D>().isTrigger = true;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;

        GameEvents.RaiseFragmentCollected(_data);
        AudioManager.Instance?.PlaySfx("fragment_pickup");
        ObjectPool.Instance?.Spawn(_pickupVfxPoolId, transform.position, Quaternion.identity);

        gameObject.SetActive(false);
    }
}
