using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

/// <summary>
/// Runtime inventory: tracks item counts and collected memory-fragment ids.
/// Referenced by GameManager and read by SaveLoadManager/EndingManager.
/// </summary>
public class InventorySystem : MonoBehaviour
{
    [Serializable]
    public class InventoryEntry
    {
        public string itemId;
        public int count;
    }

    private readonly Dictionary<string, int> _items = new Dictionary<string, int>();
    private readonly HashSet<string> _collectedFragmentIds = new HashSet<string>();

    public event Action OnInventoryChanged;

    public void AddItem(ItemSO item, int amount = 1)
    {
        if (item == null) return;
        if (!_items.ContainsKey(item.itemId)) _items[item.itemId] = 0;

        _items[item.itemId] += item.stackable ? amount : 1;
        OnInventoryChanged?.Invoke();
    }

    public bool RemoveItem(string itemId, int amount = 1)
    {
        if (!_items.ContainsKey(itemId) || _items[itemId] < amount) return false;
        _items[itemId] -= amount;
        OnInventoryChanged?.Invoke();
        return true;
    }

    public bool HasItem(string itemId, int amount = 1) =>
        _items.TryGetValue(itemId, out var c) && c >= amount;

    public int GetCount(string itemId) => _items.TryGetValue(itemId, out var c) ? c : 0;

    public void MarkFragmentCollected(string fragmentId) => _collectedFragmentIds.Add(fragmentId);
    public bool HasFragment(string fragmentId) => _collectedFragmentIds.Contains(fragmentId);
    public IReadOnlyCollection<string> CollectedFragmentIds => _collectedFragmentIds;

    public void Clear()
    {
        _items.Clear();
        _collectedFragmentIds.Clear();
        OnInventoryChanged?.Invoke();
    }

    // ---- Serialization helpers used by SaveLoadManager ----
    public List<InventoryEntry> ExportItems() =>
        _items.Select(kv => new InventoryEntry { itemId = kv.Key, count = kv.Value }).ToList();

    public List<string> ExportFragments() => _collectedFragmentIds.ToList();

    public void ImportState(List<InventoryEntry> items, List<string> fragments)
    {
        _items.Clear();
        foreach (var e in items) _items[e.itemId] = e.count;

        _collectedFragmentIds.Clear();
        foreach (var f in fragments) _collectedFragmentIds.Add(f);

        OnInventoryChanged?.Invoke();
    }
}
