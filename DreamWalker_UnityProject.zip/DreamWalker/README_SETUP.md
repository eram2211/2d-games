# Dream Walker — Unity Project (Scripts Package)

A 2D story-driven puzzle platformer where the player is trapped in five emotional
dream worlds (Fear, Joy, Sadness, Anger, Hope) and must collect memory fragments
to wake up. This package contains the **complete gameplay codebase** (C#), organized
into a modular architecture (state machines, event bus, object pooling, ScriptableObjects).

This is a scripts-only package — Unity projects also need art, audio clips, scenes,
prefabs and Inspector wiring, which can't be generated as code. Everything below tells
you exactly how to assemble those around the scripts.

---

## 1. Project setup

1. Create a new Unity project: **2D (URP)** template. URP is required because
   `DynamicLight2DController` and `VisibilityController` use `Light2D` (2D Lighting).
   - Unity version: 2022.3 LTS or newer recommended.
2. Install via Package Manager:
   - `TextMeshPro` (import TMP Essentials when prompted — used by UI scripts).
   - `Universal RP` (comes with the 2D URP template).
   - `2D Animation`, `2D Pixel Perfect` (for crisp pixel art rendering).
3. Copy the `Assets/Scripts` folder from this package into your project's `Assets/`.
4. Project Settings:
   - **Tags**: add `Player`.
   - **Layers**: add `Ground`, `Player`, `Enemy`, `Hazard`.
   - **Input Manager**: default `Horizontal`, `Vertical`, `Jump` axes already exist and are used as-is.
   - **Physics2D**: set gravity as desired (base gravity is also driven per-world by `DreamWorldSO`).
   - Camera → set to **Pixel Perfect Camera** component for crisp pixel art, orthographic.

---

## 2. Folder-by-folder script guide

| Folder | Purpose |
|---|---|
| `Core/` | `GameManager` (flow state machine), `GameEvents` (global event bus), `StateMachine`/`IState` (generic FSM), `ObjectPool` (pooling) |
| `Player/` | `PlayerController` (movement/physics), `PlayerStates` (Idle/Run/Jump/Fall/Hurt), `PlayerHealth` |
| `DreamWorlds/` | `DreamWorldSO` (per-world tuning asset), `DreamWorldManager` (applies world rules), `WeatherController`, `VisibilityController` |
| `Items/` | `ItemSO`, `MemoryFragmentData`, `MemoryFragment` (pickup), `InventorySystem` |
| `Dialogue/` | `DialogueSO` (branching dialogue asset), `DialogueManager`, `NPCInteractable` |
| `SaveSystem/` | `SaveData`, `SaveLoadManager` (JSON to `Application.persistentDataPath`) |
| `Checkpoints/` | `Checkpoint`, `CheckpointManager` |
| `Enemies/` | `EnemyBase`, `FearMonster`, `BossController` (phase FSM) |
| `Hazards/` | `BreakableWall`, `LavaHazard`, `FloatingPlatform`, `HiddenPlatform` |
| `Endings/` | `EndingType`, `EndingManager` (multiple-endings logic) |
| `Audio/` | `AudioManager` (music crossfade + pooled SFX), `FootstepController` |
| `UI/` | Main menu, settings, health bar, inventory, dialogue box, pause menu |
| `CameraSystem/` | `SmoothCameraFollow` (no Cinemachine dependency) |
| `Lighting/` | `DynamicLight2DController` (per-world ambient mood) |

---

## 3. Scene setup (per dream world scene, e.g. `Dream_Fear`)

Create one scene per world: `MainMenu`, `Dream_Fear`, `Dream_Joy`, `Dream_Sadness`,
`Dream_Anger`, `Dream_Hope`, `Boss_Arena`.

In each `Dream_*` scene:

1. **Player** — empty GameObject with: `Rigidbody2D` (Dynamic, Freeze Z rotation),
   `Collider2D`, `SpriteRenderer` + pixel-art animation, `Animator`, `PlayerController`,
   `PlayerHealth`, `FootstepController`. Add a child empty `GroundCheck` positioned at the feet
   and assign it + the `Ground` layer mask on `PlayerController`. Tag it `Player`.
2. **GameManager object** (persists via `DontDestroyOnLoad`, so only needs to exist once —
   put it in `MainMenu` scene): attach `GameManager`, `InventorySystem`, `SaveLoadManager`,
   `CheckpointManager`, `EndingManager`, `AudioManager`, `DialogueManager`. Wire references
   in Inspector (Inventory, SaveLoad, Checkpoints, DreamWorlds).
3. **World Manager object**: `DreamWorldManager` + `WeatherController` +
   `DynamicLight2DController` + `VisibilityController`, referencing the Player. Assign the
   matching `DreamWorldSO` asset (see §4) to `_activeWorld`.
4. **Main Camera**: `SmoothCameraFollow` targeting the Player, plus `Pixel Perfect Camera`
   and a `Light2D` (Global) for `DynamicLight2DController` to drive.
5. **Level geometry**: Tilemap(s) on the `Ground` layer with `TilemapCollider2D` +
   `CompositeCollider2D`. Place `MemoryFragment`, `Checkpoint`, `NPCInteractable`,
   and world-specific hazard prefabs (see §5) throughout the level.
6. **Canvas (UI)**: `HealthBarUI`, `InventoryUI`, `DialogueUI`, `PauseMenuController` —
   only needs to exist once if you mark the Canvas `DontDestroyOnLoad` from a bootstrap
   script, or duplicate it per scene and re-wire.

---

## 4. Creating the 5 Dream World ScriptableObjects

`Assets > Create > DreamWalker > Dream World Config` — make five assets and tune them
to match the brief:

| World | moveSpeedMult | jumpForceMult | gravityMult | visibility | rain | enemies | breakable walls | lava | hidden platforms | floating platforms |
|---|---|---|---|---|---|---|---|---|---|---|
| **Fear** | 1.0 | 1.0 | 1.0 | ✅ (small radius) | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ |
| **Joy** | 1.0 | 1.4 | 0.8 | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| **Sadness** | 0.6 | 1.0 | 1.0 | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Anger** | 1.1 | 1.0 | 1.0 | ❌ | ❌ | ❌ | ✅ | ✅ | ❌ | ❌ |
| **Hope** | 1.0 | 1.0 | 1.0 | ❌ | ❌ (floating particles ✅) | ❌ | ❌ | ❌ | ✅ | ❌ |

Set `ambientLightColor`/`ambientIntensity` per world for mood (e.g. Fear = dark
blue-grey low intensity, Joy = warm gold bright, Sadness = desaturated pale blue,
Anger = deep red, Hope = soft warm white). Assign `musicTrack`/`ambientTrack` clips.

---

## 5. Prefabs to build

- **MemoryFragment** — sprite + trigger `Collider2D` + `MemoryFragment` script,
  with a `MemoryFragmentData` asset assigned per instance.
- **Checkpoint** — trigger volume + `Checkpoint` script (unique `checkpointId` per instance).
- **NPC** — sprite + trigger `Collider2D` + `NPCInteractable` + a `DialogueSO` asset.
- **FearMonster** — sprite/animator + `Rigidbody2D` + `Collider2D` + `FearMonster` script,
  with `pointA`/`pointB` patrol markers as children in the scene.
- **BreakableWall / LavaHazard (trigger)/ FloatingPlatform / HiddenPlatform** — one prefab
  each per §Hazards scripts above, used only in their relevant world scenes.
- **Boss** — in `Boss_Arena` scene: sprite/animator + `Rigidbody2D` + `Collider2D` +
  `BossController`. Animator needs states: `Boss_Phase1_Idle`, `Boss_Phase1_Attack`,
  `Boss_Phase2_Idle`, `Boss_Phase2_Attack`, `Boss_Defeated`.
- **VFX pool prefabs** for `ObjectPool`: `FragmentSparkle`, `EnemyDeathPoof`, `WallDebris`
  — simple `ParticleSystem` prefabs, registered in the `ObjectPool` component's Pool list
  with matching `id` strings used in code (`Spawn("FragmentSparkle", ...)` etc).

## 6. Player Animator

Create an Animator Controller with states matching the strings used in `PlayerStates.cs`
and `BossController.cs`: `Idle`, `Run`, `Jump`, `Fall`, `Hurt` for the player (simple
`Animator.Play("StateName")` calls — no parameters needed, keeping it lightweight).

## 7. Audio Mixer

Create an `AudioMixer` asset with exposed parameters **MasterVolume**, **MusicVolume**,
**SFXVolume** (right-click each group's volume slider → Expose to script → rename to
match exactly, since `AudioManager.SetMasterVolume` etc. reference these names).
Route `musicSourceA/B`, `ambientSource` and `sfxSource` AudioSources to the matching
mixer groups.

## 8. Multiple Endings flow

`EndingManager` combines fragment-collection percentage with `EndingType` influence
accumulated from dialogue choices (`DialogueSO.Choice.endingInfluence`). Author NPC
dialogue so meaningful choices tag an `EndingType` (e.g. compassionate responses tag
`TrueAwakening`/`AcceptanceEnding`, dismissive/cruel responses tag `LostInDreams`).
After the boss fight, `GameManager` calls `EndingManager.EvaluateEnding(...)` and
raises `GameEvents.OnEndingTriggered`; build an `EndingSequenceController` (simple,
project-specific — plays a cutscene/slideshow per `EndingType`) that subscribes to it.

## 9. Save/Load

`SaveLoadManager.Save()`/`Load()` read/write JSON to
`Application.persistentDataPath/dreamwalker_save.json`. Auto-saves on checkpoint by
default (`Checkpoint._autoSaveOnReach`); also wire a manual "Save" button in the pause
menu (`PauseMenuController.OnSave`) and "Continue" on the main menu
(`MainMenuController.OnContinue`, already checks `SaveLoadManager.HasSave()`).

## 10. Architecture notes (why it's built this way)

- **Event bus (`GameEvents`)** decouples systems — e.g. `PlayerHealth` doesn't know
  the UI exists; it just raises an event, and `HealthBarUI` listens.
- **State machines (`StateMachine`/`IState`)** are reused for player movement, boss
  phases, and game flow (`GameManager.Flow`) — one small, well-tested pattern instead
  of three different ad-hoc implementations.
- **ScriptableObjects** (`DreamWorldSO`, `ItemSO`, `MemoryFragmentData`, `DialogueSO`)
  let designers/writers tune worlds, items and conversations from the Inspector with
  zero code changes, and make new content (a 6th dream world, a new NPC) purely additive.
- **Object pooling (`ObjectPool`)** avoids GC/instantiate spikes for particles and VFX
  that fire constantly (footstep dust, pickup sparkles, hit effects).
- All scripts are commented explaining *why*, not just *what*, per file.

## 11. Suggested next steps

1. Import placeholder pixel-art (e.g. Kenney.nl 2D packs) to block out worlds quickly.
2. Build `MainMenu` scene first end-to-end (buttons wired, settings working) since it's
   the game's entry point and easiest to test in isolation.
3. Build `Dream_Fear` fully (this validates PlayerController, enemies, visibility, save)
   before duplicating the pattern for the remaining four worlds.
4. Build `Boss_Arena` and hook `EndingManager` last, once fragment totals across all
   five worlds are finalized (`GameManager.TotalFragments`).
